# Migration summary

- Set `applicationId` to `com.ssai.usbtool`; retained Java package names to minimize invasive refactoring.
- Set app and library compile/target SDK to API 29.
- Set min SDK to 21 and native ABI to `arm64-v8a`.
- Replaced obsolete AGP 3.0.1 / Gradle 4.1 / JCenter setup with AGP 7.4.2 / Gradle 7.5 / Google Maven + Maven Central.
- Replaced legacy `compile` dependency configurations with `implementation`.
- Replaced removed `gnustl_static` with `c++_static`.
- Enabled V1 and V2 on the debug signing config.

This is a build-system migration pass, not a claim that every original native hook or third-party SDK is already compatible with Android 10. See `BUILD_ANDROID10_ARM64.md`.
