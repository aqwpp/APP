# USBTool / VirtualApp Android 10 ARM64 migration

## Target
- Application ID: `com.ssai.usbtool`
- Source Java namespace: `io.virtualapp` (kept to avoid breaking legacy source references)
- Library namespace: `com.lody.virtual`
- compileSdk / targetSdk: 29
- minSdk: 21
- Native ABI: `arm64-v8a` only
- Gradle: 7.5; Android Gradle Plugin: 7.4.2
- Java: JDK 11 recommended
- Debug APK signing: V1 + V2 enabled (Android debug keystore; test use only)

## Build
Install Android SDK Platform 29, Android SDK Build-Tools, and Android NDK (r25.2 or compatible). Then run from this directory:

```bash
./gradlew :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`. The debug build uses the standard Android debug keystore and has both JAR signing (V1) and APK Signature Scheme v2 enabled. For a distributable release, configure your own keystore and do not ship the debug key.

## Important migration blockers / validation
1. The uploaded upstream tree originally targeted compileSdk 26 / targetSdk 22, Gradle 4.1 / AGP 3.0.1 and only declared `armeabi-v7a` + `x86` for the native VirtualApp library. This migration changes the build declarations to ARM64, but does not by itself prove the old native hooks are stable on Android 10.
2. The bundled Tencent location native library only contains `armeabi`, `armeabi-v7a`, and `x86`; no `arm64-v8a` binary was present in the supplied archive. Location/map features that load that SDK may not work on ARM64 until a licensed ARM64 Tencent SDK binary is supplied or that optional feature is removed.
3. The native project includes ARM64 HookZz source folders, but the complete native build and runtime behavior must be verified using the selected NDK and an Android 10 ARM64 device.
4. No Android SDK/NDK is bundled with this source package. This archive is a migrated source project, not a compiled or device-verified APK.
5. Review the upstream README's licensing terms and retain all required notices. The user has stated that they have authorization; keep the authorization record with the project.

## Signature verification
After building, verify with Android SDK `apksigner`:

```bash
apksigner verify --verbose --print-certs app/build/outputs/apk/debug/app-debug.apk
```

The output should report `Verified using v1 scheme (JAR signing): true` and `Verified using v2 scheme (APK Signature Scheme v2): true`.
