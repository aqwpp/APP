# USBTool Virtual build notes

- Android application ID: `com.ssai.usbtool`
- Android namespace: `com.ssai.usbtool.app`
- Minimum SDK: 26 (Android 8.0)
- Target SDK: 29 (Android 10 compatibility target)
- Compile SDK: 35
- Native ABI: check `core/hook/src/main/cpp/CMakeLists.txt`; this source is intended to build ARM64 for the target device.
- JDK: 17
- Gradle wrapper: 8.9
- Android NDK: 27.1.12297006

Build a debug APK:

```bash
./gradlew :app:assembleDebug
```

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

This is an experimental no-root app-virtualization framework. It is not a full Android/QEMU guest OS. Compatibility with a specific guest APK, JNI library, MediaTek device, and 2 GB RAM device must be tested on hardware. A successful compile does not prove that every guest app will run correctly.
