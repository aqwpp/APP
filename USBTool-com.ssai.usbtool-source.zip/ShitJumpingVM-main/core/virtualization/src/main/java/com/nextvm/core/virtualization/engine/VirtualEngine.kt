package com.ssai.usbtool.core.virtualization.engine

import android.content.Context
import android.content.Intent
import com.ssai.usbtool.core.apk.VirtualClassLoader
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import com.ssai.usbtool.core.binder.BinderProxyManager
import com.ssai.usbtool.core.binder.VirtualCallerResolver
import com.ssai.usbtool.core.binder.proxy.ActivityBinderWrap
import com.ssai.usbtool.core.binder.proxy.ContentResolverProxy
import com.ssai.usbtool.core.binder.proxy.SystemServiceProxyManager
import com.ssai.usbtool.core.common.AndroidCompat
import com.ssai.usbtool.core.framework.parsing.FrameworkApkParser
import com.ssai.usbtool.core.framework.parsing.FullPackageInfo
import com.ssai.usbtool.core.hook.AntiDetectionEngine
import com.ssai.usbtool.core.hook.IdentitySpoofingEngine
import com.ssai.usbtool.core.hook.NativeHookBridge
import com.ssai.usbtool.core.model.*
import com.ssai.usbtool.core.sandbox.NativeLibManager
import com.ssai.usbtool.core.sandbox.SandboxManager
import com.ssai.usbtool.core.sandbox.VirtualEnvironmentHook
import com.ssai.usbtool.core.services.VirtualServiceManager
import com.ssai.usbtool.core.virtualization.lifecycle.GuestBreadcrumb
import com.ssai.usbtool.core.virtualization.lifecycle.VirtualApplicationManager
import com.ssai.usbtool.core.virtualization.lifecycle.VirtualConfigurationManager
import com.ssai.usbtool.core.virtualization.lifecycle.VirtualResourceManager
import com.ssai.usbtool.core.virtualization.process.VirtualMultiProcessManager
import com.ssai.usbtool.core.virtualization.ui.VirtualWindowManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * VirtualEngine — The heart of USBTool.
 *
 * Phase 2+ architecture: Uses REAL Android 16 framework code with comprehensive
 * subsystem orchestration for full guest app lifecycle.
 *
 * Sub-systems:
 * - FrameworkApkParser: APK parsing ported from Android 16's ApkLiteParseUtils
 * - VirtualServiceManager: Hosts VAMS, VPMS, service/broadcast/provider/intent/perm/network/GMS
 * - VirtualApplicationManager: Guest Application class lifecycle (instantiate, attach, onCreate)
 * - VirtualResourceManager: Guest app resource/asset loading
 * - VirtualConfigurationManager: Configuration change detection and dispatch
 * - SystemServiceProxyManager: 35 Android system service proxies
 * - ContentResolverProxy: ContentResolver interception
 * - IdentitySpoofingEngine: Build.*, ANDROID_ID, IMEI spoofing
 * - NativeHookBridge: PLT hooks for libc I/O redirect, /proc spoofing
 * - AntiDetectionEngine: Root/emulator/virtual environment detection bypass
 * - VirtualMultiProcessManager: Multi-process guest app support
 * - VirtualWindowManager: Window type management and UI interaction
 * - ActivityThread.mH hook: Runtime stub-to-real class swapping
 *
 * Initialization sequence (MUST follow this order):
 * 1. bypassHiddenApis()            → Unlock reflection access
 * 2. createVirtualDirectories()     → Set up sandbox file tree
 * 3. initializeStubRegistry()       → Map stubs to process slots
 * 4. initializeFrameworkServices()  → Start all virtual services
 * 5. installSystemServiceProxies()  → Hook 35 system services
 * 6. installNativeHooks()           → PLT hooks for file I/O & /proc
 * 7. installIdentitySpoofing()      → Device identity spoofing
 * 8. installAntiDetection()         → Root/emulator detection bypass
 * 9. installActivityThreadHook()    → Hook mH for class swapping
 * 10. loadInstalledApps()           → Restore from disk
 */
@Singleton
class VirtualEngine @Inject constructor(
    private val context: Context,
    private val frameworkApkParser: FrameworkApkParser,
    private val serviceManager: VirtualServiceManager,
    // Application lifecycle
    private val applicationManager: VirtualApplicationManager,
    private val resourceManager: VirtualResourceManager,
    private val configurationManager: VirtualConfigurationManager,
    // System service proxies
    private val systemServiceProxyManager: SystemServiceProxyManager,
    private val contentResolverProxy: ContentResolverProxy,
    // Hook / Identity / Security
    private val identitySpoofingEngine: IdentitySpoofingEngine,
    private val nativeHookBridge: NativeHookBridge,
    private val antiDetectionEngine: AntiDetectionEngine,
    // Multi-process & Window
    private val multiProcessManager: VirtualMultiProcessManager,
    private val windowManager: VirtualWindowManager,
    // External storage / Environment hooks
    private val virtualEnvironmentHook: VirtualEnvironmentHook
) {
    companion object {
        private const val TAG = "VirtualEngine"
    }

    // Engine state
    private val _status = MutableStateFlow(EngineStatus.NOT_INITIALIZED)
    val status: StateFlow<EngineStatus> = _status.asStateFlow()

    // Installed virtual apps
    private val _installedApps = MutableStateFlow<List<VirtualApp>>(emptyList())
    val installedApps: StateFlow<List<VirtualApp>> = _installedApps.asStateFlow()

    // Sub-systems
    private lateinit var stubRegistry: StubRegistry
    private lateinit var sandboxManager: SandboxManager
    private lateinit var processManager: VirtualProcessManager
    private lateinit var activityThreadHook: ActivityThreadHook
    private lateinit var binderProxyManager: BinderProxyManager

    // Virtual directories
    private lateinit var virtualRoot: File
    private lateinit var apksDir: File
    private lateinit var dataDir: File

    // ClassLoader cache: instanceId -> DexClassLoader
    private val classLoaders = mutableMapOf<String, ClassLoader>()

    // Running apps: instanceId -> process slot
    private val runningApps = mutableMapOf<String, Int>()

    // Thread-safety lock for initialization
    private val initLock = Any()

    // Flag to track if early ATHook was installed
    private var earlyHookInstalled = false

    /**
     * Install the ActivityThread.mH hook EARLY, synchronously on the main thread.
     *
     * This MUST be called in Application.onCreate() BEFORE the background init starts.
     * In child processes (:p0, :p1), Android sends EXECUTE_TRANSACTION immediately
     * after Application.onCreate() returns, so ATHook must be ready by then.
     *
     * This method does the minimum work needed for ATHook:
     * 1. Hidden API bypass (needed for reflection)
     * 2. StubRegistry initialization (needed for stub→real class mapping)
     * 3. ATHook installation (hooks ActivityThread.mH.mCallback)
     */
    /**
     * v44: wrap the raw "activity" binder in ServiceManager's cache.
     * Must run synchronously from Application.onCreate — before any
     * guest code can capture the binder — because launch61 proved
     * guest AMS traffic uses that raw channel, not the replaced
     * ActivityManager singleton. Hidden-API bypass runs first inside
     * installActivityThreadHookEarly; this is called right after it.
     */
    fun installActivityBinderWrapEarly(context: Context) {
        ActivityBinderWrap.install(context)
    }

    fun installActivityThreadHookEarly(context: Context) {
        try {
            // 1. Hidden API bypass (fast, ~10ms)
            AndroidCompat.bypassHiddenApis()

            // 2. Initialize virtual directories early so getDataDir()/getNativeLibDir()
            // work immediately when handleLaunchActivityItem runs on the main thread
            // BEFORE the background initialize() has completed.
            if (!::virtualRoot.isInitialized) {
                virtualRoot = File(context.filesDir, VirtualConstants.VIRTUAL_DIR)
                apksDir = File(virtualRoot, VirtualConstants.VIRTUAL_APKS_DIR)
                dataDir = File(virtualRoot, VirtualConstants.VIRTUAL_DATA_DIR)
                virtualRoot.mkdirs()
                apksDir.mkdirs()
                dataDir.mkdirs()
            }

            // 3. Initialize StubRegistry (fast, ~5ms)
            if (!::stubRegistry.isInitialized) {
                stubRegistry = StubRegistry()
            }

            // 4. Install ATHook synchronously (hooks mH.mCallback + Instrumentation)
            if (!::activityThreadHook.isInitialized) {
                activityThreadHook = ActivityThreadHook(context, stubRegistry, this)
                activityThreadHook.install()
                // CRITICAL: Install Instrumentation hook immediately so newActivity()
                // is intercepted from the very first EXECUTE_TRANSACTION message.
                // Without this, the system Instrumentation will try to load guest
                // classes with the wrong ClassLoader, causing ClassNotFoundException.
                activityThreadHook.installInstrumentationHookEarly()
            }

            earlyHookInstalled = true
            Timber.tag(TAG).i("ATHook installed early (main thread) ✓")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to install early ATHook — guest apps may show blank screen")
        }
    }

    /**
     * Initialize the virtual engine.
     * MUST be called before any other operation.
     * Order matters — follow the sequence exactly.
     * Thread-safe: concurrent calls are handled gracefully.
     */
    fun initialize(): VmResult<Unit> {
        synchronized(initLock) {
            if (_status.value == EngineStatus.READY) {
                Timber.tag(TAG).d("Engine already initialized")
                return VmResult.Success(Unit)
            }

            if (_status.value == EngineStatus.INITIALIZING) {
                Timber.tag(TAG).d("Engine initialization already in progress, waiting...")
                // Wait for existing init to complete (max 30 seconds)
                val startTime = System.currentTimeMillis()
                while (_status.value == EngineStatus.INITIALIZING) {
                    if (System.currentTimeMillis() - startTime > 30_000) {
                        return VmResult.Error("Engine initialization timed out")
                    }
                    Thread.sleep(100)
                }
                return if (_status.value == EngineStatus.READY) {
                    VmResult.Success(Unit)
                } else {
                    VmResult.Error("Engine initialization failed")
                }
            }

            _status.value = EngineStatus.INITIALIZING
        Timber.tag(TAG).i("Initializing USBTool Virtual Engine (Phase 2+)...")

        try {
            // Step 1: Bypass hidden API restrictions (MUST be first)
            if (!AndroidCompat.bypassHiddenApis()) {
                Timber.tag(TAG).w("Hidden API bypass failed — some features may not work")
            }

            // Step 2: Create virtual directory structure
            createVirtualDirectories()

            // Step 3: Initialize core sub-systems
            // (Skip StubRegistry if already initialized by installActivityThreadHookEarly)
            if (!::stubRegistry.isInitialized) {
                stubRegistry = StubRegistry()
            }
            sandboxManager = SandboxManager(context, virtualRoot)
            processManager = VirtualProcessManager(VirtualConstants.MAX_PROCESS_SLOTS)

            // Step 4: Initialize ALL framework services (VPMS + VAMS + 7 more services)
            serviceManager.initialize(context)
            Timber.tag(TAG).d("Framework services initialized (9 services)")

            // Step 5: Install system service proxies (35 Android system services)
            systemServiceProxyManager.installAllProxies(context)
            Timber.tag(TAG).d("System service proxies installed (35 services)")

            // Step 5.5: Install IActivityManager + IPackageManager Binder proxies
            // These intercept critical IPC calls (startActivity, getContentProvider, etc.)
            // and fix callingPackage to match the host UID, preventing SecurityException.
            binderProxyManager = BinderProxyManager(context, serviceManager.packageManager)
            binderProxyManager.installAllProxies()
            Timber.tag(TAG).d("Binder proxies installed (IActivityManager + IPackageManager)")

            // Step 5.6: Connect GMS service router to ActivityManagerProxy + PackageManagerProxy
            // This enables guest app bindService() calls to GMS packages to be
            // routed through the Hybrid GMS bridge for identity spoofing.
            binderProxyManager.setGmsRouter(serviceManager.gmsManager)
            Timber.tag(TAG).d("GMS service router connected to Binder proxy")

            // Step 5.7: Connect GMS router to SystemServiceProxyManager for account isolation
            // Each virtual instance will only see its own Google account (not all host accounts)
            systemServiceProxyManager.setGmsRouter(serviceManager.gmsManager)
            Timber.tag(TAG).d("GMS service router connected to SystemServiceProxy (account isolation)")

            // Step 6: Install ContentResolver proxy
            contentResolverProxy.install(context)
            Timber.tag(TAG).d("ContentResolver proxy installed")

            // Step 7: Install native PLT hooks (file I/O redirect, /proc spoofing)
            // NOTE: Native GOT patching can SIGSEGV on some devices if libraries have
            // Full RELRO or unusual ELF layouts. We catch any exception from the Kotlin
            // side, but a native crash will still terminate the process. The native code
            // includes address validation to prevent this.
            try {
                nativeHookBridge.initNativeHooks(context)
                Timber.tag(TAG).d("Native hook bridge initialized")
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "Native hook bridge failed — Java-level hooks only")
            }

            // Step 8: Initialize identity spoofing engine
            identitySpoofingEngine.initialize()
            Timber.tag(TAG).d("Identity spoofing engine initialized")

            // Step 9: Initialize anti-detection engine
            antiDetectionEngine.initialize()
            Timber.tag(TAG).d("Anti-detection engine initialized")

            // Step 10: Initialize application lifecycle manager
            applicationManager.initialize(context)
            Timber.tag(TAG).d("Application lifecycle manager initialized")

            // Step 11: Initialize resource manager
            resourceManager.initialize(context)
            Timber.tag(TAG).d("Resource manager initialized")

            // Step 12: Initialize configuration change manager
            configurationManager.initialize(context)
            Timber.tag(TAG).d("Configuration change manager initialized")

            // Step 13: Initialize multi-process manager
            multiProcessManager.initialize(context)
            Timber.tag(TAG).d("Multi-process manager initialized")

            // Step 14: Initialize window manager
            windowManager.initialize(context)
            Timber.tag(TAG).d("Window manager initialized")

            // Step 14b: Initialize network manager
            serviceManager.networkManager.initialize(context)
            Timber.tag(TAG).d("Network manager initialized")

            // Note: Hybrid GMS Manager is initialized by serviceManager.initialize() above

            // Step 15: Hook ActivityThread.mH for class swapping
            // (Skip if already installed by installActivityThreadHookEarly)
            if (!earlyHookInstalled) {
                activityThreadHook = ActivityThreadHook(context, stubRegistry, this)
                activityThreadHook.install()
            }

            // Step 16: Load previously installed apps from disk
            loadInstalledApps()

            _status.value = EngineStatus.READY
            Timber.tag(TAG).i("USBTool Virtual Engine initialized successfully (all subsystems online)")
            return VmResult.Success(Unit)

        } catch (e: Exception) {
            _status.value = EngineStatus.ERROR
            Timber.tag(TAG).e(e, "Failed to initialize virtual engine")
            return VmResult.Error("Engine initialization failed: ${e.message}", e)
        }
        } // synchronized(initLock)
    }

    /**
     * Install an APK into the virtual environment.
     */
    fun installApp(apkPath: String): VmResult<VirtualApp> {
        ensureInitialized()

        Timber.tag(TAG).i("Installing APK: $apkPath")

        try {
            // 1. Parse APK using Android 16 framework parser
            val apkFile = File(apkPath)
            val result = frameworkApkParser.parseFullPackage(apkFile)
            val parseResult = when (result) {
                is com.ssai.usbtool.core.framework.parsing.ParseResult.Success -> result.result
                is com.ssai.usbtool.core.framework.parsing.ParseResult.Error -> {
                    return VmResult.Error("Failed to parse APK: ${result.errorMessage ?: "unknown error"}")
                }
            }

            val packageName = parseResult.packageName
            val appName = parseResult.appName

            Timber.tag(TAG).d("Parsed APK: $packageName ($appName)")

            // 2. Generate unique instance ID
            val instanceId = "${packageName}_${System.currentTimeMillis()}"

            // 3. Copy APK to virtual storage
            val virtualApkPath = copyApkToVirtualStorage(apkPath, instanceId, packageName)

            // 3.5. Discover and COPY split APKs (critical for Unity/native apps)
            // Split APKs contain native libs (libmain.so, libil2cpp.so, etc.)
            // that Play Store app bundles separate into split_config.{abi}.apk
            val discoveredSplits = discoverSplitApks(apkPath, packageName)
            val virtualSplitPaths = mutableListOf<String>()
            if (discoveredSplits.isNotEmpty()) {
                Timber.tag(TAG).d("Discovered ${discoveredSplits.size} split APKs for $packageName")
                for (splitPath in discoveredSplits) {
                    try {
                        val splitName = File(splitPath).name
                        val destFile = File(apksDir, "${instanceId}_${splitName}")
                        File(splitPath).copyTo(destFile, overwrite = true)
                        destFile.setWritable(false, false)
                        destFile.setReadable(true, false)
                        destFile.setExecutable(false, false)
                        createApkGuardLink(destFile)
                        virtualSplitPaths.add(destFile.absolutePath)
                        Timber.tag(TAG).d("Copied split APK: $splitName")
                    } catch (e: Exception) {
                        Timber.tag(TAG).w("Failed to copy split $splitPath: ${e.message}")
                        // Try using original path as fallback
                        virtualSplitPaths.add(splitPath)
                    }
                }
            }

            // 4. Extract native libraries using NativeLibManager (handles all APKs)
            val allApkPaths = buildList {
                add(virtualApkPath)
                addAll(virtualSplitPaths)
            }
            val dataRoot = File(virtualRoot, "data")
            val nativeLibResult = NativeLibManager.extractNativeLibs(allApkPaths, instanceId, dataRoot)

            // 5. Create isolated data directory tree
            sandboxManager.createAppDataDir(instanceId, packageName)

            // 6. Assign process slot
            val slot = processManager.allocateSlot(instanceId)
            if (slot < 0) {
                return VmResult.Error("No free process slots available (max: ${VirtualConstants.MAX_PROCESS_SLOTS})")
            }

            // 7. Main launcher activity (already found during parsing)
            val mainActivity = parseResult.mainActivity

            // 8. Determine native ABI support
            val nativeAbis = parseResult.nativeAbis.ifEmpty {
                parseResult.apkLite?.let { apkLite ->
                    val abis = mutableListOf<String>()
                    if (apkLite.isMultiArch) abis.add("multi-arch")
                    abis
                } ?: emptyList()
            }

            // 9. Create VirtualApp record with Android 16 framework fields
            // Build activity-alias mapping: alias name → real target activity
            val activityAliases = parseResult.activities
                .filter { it.targetActivity != null }
                .associate { it.className to it.targetActivity!! }

            val virtualApp = VirtualApp(
                packageName = packageName,
                appName = appName,
                versionName = parseResult.versionName,
                versionCode = parseResult.versionCode,
                icon = parseResult.icon,
                apkPath = virtualApkPath,
                instanceId = instanceId,
                processSlot = slot,
                is64Bit = parseResult.apkLite?.isMultiArch != false,
                mainActivity = mainActivity,
                activities = parseResult.activities.map { it.className },
                services = parseResult.services.map { it.className },
                providers = parseResult.providers.map { it.className },
                receivers = parseResult.receivers.map { it.className },
                // Android 16 framework fields
                minSdkVersion = parseResult.apkLite?.minSdkVersion ?: 1,
                targetSdkVersion = parseResult.apkLite?.targetSdkVersion ?: 35,
                isMultiArch = parseResult.apkLite?.isMultiArch ?: false,
                use32bitAbi = parseResult.apkLite?.use32bitAbi ?: false,
                extractNativeLibs = parseResult.apkLite?.extractNativeLibs ?: true,
                useEmbeddedDex = parseResult.apkLite?.useEmbeddedDex ?: false,
                isDebuggable = parseResult.apkLite?.isDebuggable ?: false,
                installLocation = parseResult.apkLite?.installLocation ?: 0,
                pageSizeCompat = parseResult.apkLite?.pageSizeCompat ?: 0,
                splitApkPaths = virtualSplitPaths.ifEmpty {
                    parseResult.packageLite?.splitApkPaths ?: emptyList()
                },
                splitNames = parseResult.packageLite?.splitNames ?: emptyList(),
                hasSplitApks = (parseResult.packageLite?.splitApkPaths?.isNotEmpty()) == true,
                isolatedSplits = parseResult.apkLite?.isolatedSplits ?: false,
                applicationClassName = parseResult.applicationClassName,
                requestedPermissions = parseResult.permissions,
                nativeAbis = nativeAbis,
                activityAliases = activityAliases,
                dataDir = sandboxManager.getAppDir(instanceId).absolutePath,
                libDir = nativeLibResult.libDir,
                librarySearchPath = nativeLibResult.librarySearchPath,
                primaryAbi = nativeLibResult.selectedAbi,
                cacheDir = sandboxManager.getCacheDir(instanceId).absolutePath
            )

            // 10. Register in virtual PMS (real service, not proxy)
            serviceManager.packageManager.registerPackage(virtualApp, parseResult)

            // 10.2. Initialize and AUTO-GRANT all permissions for the virtual app.
            // This ensures checkPermission/checkOp returns GRANTED for everything,
            // so guest apps never see permission denial dialogs or Settings redirects.
            serviceManager.permissionManager.initializePermissions(
                packageName = packageName,
                requestedPermissions = parseResult.permissions,
                overrides = virtualApp.permissionOverrides
            )
            serviceManager.permissionManager.grantAllPermissions(packageName)
            Timber.tag(TAG).d("All permissions auto-granted for $packageName")

            // 10.5. Register with Binder proxies (so AMProxy/PMProxy know about this app)
            if (::binderProxyManager.isInitialized) {
                binderProxyManager.registerVirtualApp(virtualApp)
            }

            // 10.6. Register external storage for file explorer support
            virtualEnvironmentHook.registerInstance(instanceId, packageName)
            systemServiceProxyManager.registerVirtualSdcard(
                instanceId,
                sandboxManager.getExternalStorageDir(instanceId).absolutePath
            )

            // 11. Save to persistent storage
            saveVirtualApp(virtualApp)

            // 12. Update installed apps list
            val current = _installedApps.value.toMutableList()
            current.add(virtualApp)
            _installedApps.value = current

            Timber.tag(TAG).i("App installed: ${virtualApp.appName} (${virtualApp.instanceId})")
            return VmResult.Success(virtualApp)

        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to install APK: $apkPath")
            return VmResult.Error("Installation failed: ${e.message}", e)
        }
    }

    /**
     * Launch a virtual app by its instance ID.
     */
    fun launchApp(instanceId: String): VmResult<Unit> {
        ensureInitialized()

        val app = findApp(instanceId)
            ?: return VmResult.Error("App not found: $instanceId")

        Timber.tag(TAG).i("Launching: ${app.appName} (${app.instanceId})")

        try {
            // 1. Find main activity (from VPMS, the real service)
            val mainActivity = app.mainActivity
                ?: serviceManager.packageManager.getMainActivity(app.packageName)
                ?: return VmResult.Error("No main activity found for ${app.packageName}")

            // 2. Get launch mode from VPMS and convert to string for StubRegistry
            val launchModeInt = serviceManager.packageManager.getActivityLaunchMode(
                app.packageName, mainActivity
            )
            val launchMode = when (launchModeInt) {
                android.content.pm.ActivityInfo.LAUNCH_SINGLE_TOP -> "singleTop"
                android.content.pm.ActivityInfo.LAUNCH_SINGLE_TASK -> "singleTask"
                android.content.pm.ActivityInfo.LAUNCH_SINGLE_INSTANCE -> "singleInstance"
                else -> "standard"
            }

            // 3. Resolve stub class based on launch mode
            val stubClass = stubRegistry.resolveStub(
                slot = app.processSlot,
                launchMode = launchMode
            ) ?: return VmResult.Error("No available stub for process slot ${app.processSlot}")

            // 4. Build the swapped intent
            val intent = Intent().apply {
                setClassName(context.packageName, stubClass)
                putExtra(VirtualIntentExtras.TARGET_PACKAGE, app.packageName)
                putExtra(VirtualIntentExtras.TARGET_ACTIVITY, mainActivity)
                putExtra(VirtualIntentExtras.INSTANCE_ID, app.instanceId)
                putExtra(VirtualIntentExtras.APK_PATH, app.apkPath)
                putExtra(VirtualIntentExtras.PROCESS_SLOT, app.processSlot)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // 5. Create ClassLoader for guest app (if not cached)
            if (!classLoaders.containsKey(instanceId)) {
                val classLoader = VirtualClassLoader.createClassLoader(
                    apkPath = app.apkPath,
                    instanceId = instanceId,
                    parentDir = virtualRoot,
                    prebuiltLibrarySearchPath = app.librarySearchPath.ifEmpty { null },
                    splitApkPaths = app.splitApkPaths
                )
                classLoaders[instanceId] = classLoader
                GuestClassLoaderRegistry.register(app.packageName, instanceId, classLoader)
            }

            // 6. Register process start in VAMS (real service)
            serviceManager.activityManager.startProcess(
                packageName = app.packageName,
                instanceId = app.instanceId,
                processSlot = app.processSlot
            )

            // 7. Start activity in VAMS
            serviceManager.activityManager.startActivity(
                packageName = app.packageName,
                activityName = mainActivity,
                instanceId = app.instanceId,
                stubClassName = stubClass,
                launchMode = launchModeInt
            )

            // 8. Register in running apps
            runningApps[instanceId] = app.processSlot

            // 8.3: Activate external storage hooks for this instance.
            // This redirects Environment.getExternalStorageDirectory() and
            // file I/O paths (/sdcard/, /storage/emulated/0/) to the sandbox.
            val sdcardDir = sandboxManager.getExternalStorageDir(instanceId)
            virtualEnvironmentHook.activateForInstance(instanceId, app.packageName)
            nativeHookBridge.setupExternalStorageRedirections(instanceId, sdcardDir.absolutePath)

            // 8.5: Install any deferred service proxies (e.g., NotificationManager)
            systemServiceProxyManager.installDeferredProxies()

            // 9. Mark as launched in VPMS
            serviceManager.packageManager.markAsLaunched(app.packageName)

            // 10. Update app state
            updateAppState(instanceId) { it.copy(isRunning = true, lastLaunchedAt = System.currentTimeMillis()) }

            // 10.5: Drain any FCM messages that arrived while the app was offline.
            // These are queued by NextVmFcmService when the target instance wasn't running.
            try {
                val fcmProxy = serviceManager.gmsManager.fcmProxy
                val pending = fcmProxy.drainPendingMessages(instanceId)
                if (pending.isNotEmpty()) {
                    Timber.tag(TAG).d("Draining ${pending.size} queued FCM messages for $instanceId")
                    pending.forEach { message ->
                        val deliveryIntent = fcmProxy.buildDeliveryIntent(instanceId, message)
                        deliverFcmToInstance(instanceId, deliveryIntent)
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w("FCM drain failed for $instanceId: ${e.message}")
            }

            // 11. Launch via real system (it sees a valid stub component)
            context.startActivity(intent)

            Timber.tag(TAG).i("Launched: ${app.appName} via stub $stubClass (launchMode=$launchMode)")
            return VmResult.Success(Unit)

        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to launch: ${app.appName}")
            return VmResult.Error("Launch failed: ${e.message}", e)
        }
    }

    /**
     * Stop a running virtual app.
     */
    fun stopApp(instanceId: String): VmResult<Unit> {
        val slot = runningApps.remove(instanceId)
        if (slot != null) {
            // Kill process in VAMS (takes instanceId, not slot)
            serviceManager.activityManager.killProcess(instanceId)
            processManager.releaseSlot(slot)
            classLoaders.remove(instanceId)
            val pkg = findApp(instanceId)?.packageName ?: instanceId.substringBefore('_')
            GuestClassLoaderRegistry.unregister(pkg, instanceId)

            // Deactivate storage hooks for this instance
            nativeHookBridge.removeExternalStorageRedirections()
            nativeHookBridge.removeAppRedirections(pkg)
            nativeHookBridge.removePathFidelityRedirections(pkg)
            virtualEnvironmentHook.deactivate()

            // Clean up GMS state (FCM tokens, auth state, Binder connections, billing)
            try {
                serviceManager.gmsManager.cleanupInstance(instanceId)
            } catch (e: Exception) {
                Timber.tag(TAG).w("GMS cleanup failed for $instanceId: ${e.message}")
            }

            updateAppState(instanceId) { it.copy(isRunning = false) }
            Timber.tag(TAG).i("Stopped app: $instanceId")
        }
        return VmResult.Success(Unit)
    }

    /**
     * Uninstall a virtual app.
     */
    fun uninstallApp(instanceId: String): VmResult<Unit> {
        ensureInitialized()

        // Stop if running
        stopApp(instanceId)

        val app = findApp(instanceId)
            ?: return VmResult.Error("App not found: $instanceId")

        try {
            // Remove data directory
            sandboxManager.deleteAppData(instanceId)

            // Remove APK
            File(app.apkPath).delete()

            // v81: remove guard hard links for this instance (base +
            // splits share the instanceId name prefix), otherwise the
            // inode (the full APK bytes) would never be freed.
            try {
                File(virtualRoot, ".apk_guard").listFiles()
                    ?.filter { it.name.startsWith(instanceId) }
                    ?.forEach { it.delete() }
            } catch (t: Throwable) {
                Timber.tag(TAG).w(
                    "APK guard cleanup failed for $instanceId: ${t.message}"
                )
            }

            // Unregister from virtual PMS (real service)
            serviceManager.packageManager.unregisterPackage(app.packageName)

            // Unregister from Binder proxies
            if (::binderProxyManager.isInitialized) {
                binderProxyManager.unregisterVirtualApp(app.packageName)
            }

            // Unregister external storage hooks
            virtualEnvironmentHook.unregisterInstance(instanceId)

            // Release process slot
            if (app.processSlot >= 0) {
                processManager.releaseSlot(app.processSlot)
            }

            // Remove from installed list
            val current = _installedApps.value.toMutableList()
            current.removeAll { it.instanceId == instanceId }
            _installedApps.value = current

            // Remove saved state
            deleteSavedApp(instanceId)

            Timber.tag(TAG).i("Uninstalled: ${app.appName} ($instanceId)")
            return VmResult.Success(Unit)

        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to uninstall: $instanceId")
            return VmResult.Error("Uninstall failed: ${e.message}", e)
        }
    }

    /**
     * Get the ClassLoader for a virtual app.
     */
    fun getClassLoader(instanceId: String): ClassLoader? = classLoaders[instanceId]

    /**
     * Set up a binder interceptor on a VirtualContext that wraps GMS binders
     * in GmsBinderProxy. This ensures bindService() calls from DynamiteModule-loaded
     * GMS code (Firebase measurement, analytics, etc.) get proxied binders with
     * proper package identity rewriting.
     */
    private fun setupBinderInterceptor(
        virtualContext: com.ssai.usbtool.core.sandbox.VirtualContext,
        instanceId: String,
        guestPackageName: String
    ) {
        val gmsManager = serviceManager.gmsManager
        val bridge = gmsManager.binderBridge
        val spoofer = gmsManager.identitySpoofer
        virtualContext.setBinderInterceptor { componentName, binder, intent ->
            // Check if this binder is from a GMS service
            val targetPkg = componentName?.packageName
                ?: intent?.component?.packageName
                ?: intent?.`package`
            val isGms = targetPkg != null && (
                    targetPkg == com.ssai.usbtool.core.services.gms.GmsBinderBridge.GMS_PACKAGE ||
                    targetPkg == com.ssai.usbtool.core.services.gms.GmsBinderBridge.GSF_PACKAGE ||
                    targetPkg == com.ssai.usbtool.core.services.gms.GmsBinderBridge.PLAY_STORE_PACKAGE ||
                    targetPkg.startsWith("com.google.android.gms") ||
                    targetPkg.startsWith("com.google.firebase")
            )
            if (isGms && bridge.isInitialized()) {
                // Already a GmsBinderProxy? Don't double-wrap
                if (binder is com.ssai.usbtool.core.services.gms.GmsBinderBridge.GmsBinderProxy) {
                    binder
                } else {
                    spoofer.registerMapping(guestPackageName, instanceId)
                    com.ssai.usbtool.core.services.gms.GmsBinderBridge.GmsBinderProxy(
                        binder, guestPackageName, instanceId, bridge
                    )
                }
            } else {
                binder
            }
        }
    }

    /**
     * Expose the GMS manager for FCM routing from the app module.
     * Used by NextVmFcmService to route incoming push notifications.
     */
    fun getGmsManager() = serviceManager.gmsManager

    /**
     * Expose the currently running virtual apps.
     * Used by ActivityThreadHook to identify which instance is active.
     */
    fun getRunningApps(): Map<String, Int> = runningApps.toMap()

    /**
     * Deliver an FCM message intent to a specific virtual app instance.
     * Called by NextVmFcmService after routing determines the target instance.
     *
     * If the instance is currently running, the intent is sent via startService()
     * targeting the virtual stub service in the instance's process slot.
     * If the instance is offline, the message is queued in GmsFcmProxy.
     */
    fun deliverFcmToInstance(instanceId: String, deliveryIntent: android.content.Intent) {
        val app = findApp(instanceId)

        if (app == null) {
            Timber.tag(TAG).w("FCM delivery: no app found for instance $instanceId")
            return
        }

        val isRunning = runningApps.containsKey(instanceId)

        if (isRunning) {
            // App is running — deliver directly via broadcast within the virtual process
            try {
                val intent = android.content.Intent(deliveryIntent).apply {
                    // Route to the StubService in the correct process slot so the
                    // VirtualServiceLifecycleManager can forward to the guest's
                    // FirebaseMessagingService-equivalent receiver
                    setClassName(context.packageName,
                        "com.ssai.usbtool.app.stub.StubService\$P${app.processSlot}\$S00")
                    addFlags(android.content.Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                }
                context.startService(intent)
                Timber.tag(TAG).d("FCM delivered to running instance $instanceId (slot=${app.processSlot})")
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "FCM direct delivery failed for $instanceId")
                // Queue as fallback
                queueFcmForOfflineInstance(instanceId, deliveryIntent)
            }
        } else {
            // App is not running — queue the message
            queueFcmForOfflineInstance(instanceId, deliveryIntent)
        }
    }

    private fun queueFcmForOfflineInstance(instanceId: String, deliveryIntent: android.content.Intent) {
        try {
            val fcmProxy = getGmsManager().fcmProxy

            // Extract message data from the delivery intent
            val data = mutableMapOf<String, String>()
            deliveryIntent.extras?.keySet()?.forEach { key ->
                val value = deliveryIntent.getStringExtra(key)
                if (value != null) data[key] = value
            }

            val message = com.ssai.usbtool.core.services.gms.GmsFcmProxy.FcmMessage(
                from = deliveryIntent.getStringExtra("from") ?: "",
                to = deliveryIntent.getStringExtra("google.message_id") ?: "",
                messageId = deliveryIntent.getStringExtra("google.message_id") ?: "",
                data = data,
                notification = null
            )

            fcmProxy.queueMessage(instanceId, message)
            Timber.tag(TAG).d("FCM queued for offline instance $instanceId")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to queue FCM for $instanceId")
        }
    }

    /**
     * Get or create the ClassLoader for a virtual app (used lazily in child processes).
     */
    fun getOrCreateClassLoader(instanceId: String, apkPath: String): ClassLoader {
        // v138: ensure native hooks are installed synchronously BEFORE
        // building any classloader. initNativeHooks runs on VE.initialize's
        // background thread and was unsynchronized, so the first
        // getOrCreateClassLoader could run while native was not ready:
        // Kotlin rules registered but native map empty -> synthetic APK
        // open failed -> empty DexPathList (v136/v137 crashes). init is
        // now @Synchronized and idempotent: already initialized returns
        // immediately, otherwise it installs here on the calling thread.
        try {
            nativeHookBridge.initNativeHooks(context)
        } catch (e: Exception) {
            Timber.tag(TAG).w("v138 native init failed: ${e.message}")
        }
        // v137 path fidelity: register the file-I/O redirections BEFORE
        // any classloader is built. v136 registered them later in
        // ensureGuestApplicationBooted (bind time), but the framework
        // classloader is built from the synthetic sourceDir here — before
        // the rules existed — so the DexPathList came out empty and was
        // cached, crashing StartPageActivity with ClassNotFoundException.
        // This covers every caller (ATHook + boot); registration is
        // idempotent (same keys overwritten).
        findApp(instanceId)?.let { app ->
            if (VirtualConstants.isPathFidelityGuest(app.packageName)) {
                try {
                    nativeHookBridge.setupPathFidelityRedirections(
                        app.packageName,
                        instanceId,
                        sandboxManager.getAppDir(instanceId).absolutePath,
                        apkPath
                    )
                } catch (e: Exception) {
                    Timber.tag(TAG).w("v137-pathfidelity setup failed: ${e.message}")
                }
            }
        }
        // v139 probe: record redirect state BEFORE any classloader is
        // built. Written to a dedicated file (not GuestBreadcrumb, whose
        // log() drops lines before begin()) so it survives the crash that
        // follows when the DexPathList comes out empty. cached=false on
        // the first call marks the build this probe precedes.
        findApp(instanceId)?.let { app ->
            if (VirtualConstants.isPathFidelityGuest(app.packageName)) {
                try {
                    val synth = VirtualConstants.syntheticApkPath(app.packageName)
                    val synthOpen = try {
                        java.io.FileInputStream(synth).use { it.read(); "OK" }
                    } catch (e: Exception) {
                        "FAIL ${e.javaClass.simpleName}:${e.message}"
                    }
                    val realOpen = try {
                        java.io.FileInputStream(apkPath).use { it.read(); "OK" }
                    } catch (e: Exception) {
                        "FAIL ${e.javaClass.simpleName}:${e.message}"
                    }
                    val filesDir = java.io.File(sandboxManager.getAppDir(instanceId), "files")
                    filesDir.mkdirs()
                    java.io.File(filesDir, "v139-probe.log").appendText(
                        "cached=${classLoaders.containsKey(instanceId)} " +
                        "nativeAvailable=${nativeHookBridge.isNativeAvailable()} " +
                        "nativeCount=${nativeHookBridge.getNativeRedirectCount()} " +
                        "kotlinRules=${nativeHookBridge.getPathRedirectSnapshot()} " +
                        "synth=$synth synthOpen=$synthOpen apkPath=$apkPath realOpen=$realOpen\n"
                    )
                } catch (e: Exception) {
                    Timber.tag(TAG).w("v139 probe failed: ${e.message}")
                }
            }
        }
        return classLoaders.getOrPut(instanceId) {
            if (!::virtualRoot.isInitialized) {
                // Use the SAME path as createVirtualDirectories() to avoid path mismatch
                virtualRoot = File(context.filesDir, VirtualConstants.VIRTUAL_DIR)
                virtualRoot.mkdirs()
            }
            val app = findApp(instanceId)
            val frameworkCl = app?.let { createFrameworkClassLoader(it) }
            val cl = frameworkCl ?: VirtualClassLoader.createClassLoader(
                apkPath = apkPath,
                instanceId = instanceId,
                parentDir = virtualRoot,
                prebuiltLibrarySearchPath = app?.librarySearchPath?.ifEmpty { null },
                splitApkPaths = app?.splitApkPaths ?: emptyList()
            )
            val pkg = app?.packageName ?: instanceId.substringBefore('_')
            GuestClassLoaderRegistry.register(pkg, instanceId, cl)
            cl
        }
    }

    /**
     * Build the guest ClassLoader through the framework's own LoadedApk
     * machinery (ActivityThread.getPackageInfoNoCheck ->
     * LoadedApk.getClassLoader) instead of a hand-assembled
     * PathClassLoader.
     *
     * A manually constructed PathClassLoader differs from a
     * framework-built one in ways native code can observe: its
     * shared-library fields start out null (patched afterwards with
     * Unsafe), its linker namespace is created by hand with hand-picked
     * arguments, and its DexPathList is assembled outside
     * ApplicationLoaders/ClassLoaderFactory. Strong packers whose ART
     * hooks walk these structures (SecNeo's DexFileLoader) are the
     * suspected victims. This path makes the guest's class-loader
     * object graph identical in construction to a real app's.
     *
     * Returns null on any failure; the caller falls back to the manual
     * VirtualClassLoader path.
     */
    /** Framework LoadedApk per guest instance (android.app.LoadedApk, kept as Any). */
    private val frameworkLoadedApks = mutableMapOf<String, Any>()

    /** The framework LoadedApk created for this instance, if the framework path engaged. */
    fun frameworkLoadedApkFor(instanceId: String): Any? = frameworkLoadedApks[instanceId]

    /**
     * Obtain (and cache) the framework LoadedApk for a guest via
     * ActivityThread.getPackageInfoNoCheck on the guest's
     * ApplicationInfo. Returns null on any failure.
     */
    private fun createFrameworkLoadedApk(app: VirtualApp): Any? {
        frameworkLoadedApks[app.instanceId]?.let { cached ->
            GuestBreadcrumb.log(
                "createFrameworkLoadedApk cache hit pkg=${app.packageName} " +
                    loadedApkWitness(cached)
            )
            return cached
        }
        return try {
            val baseInfo = serviceManager.packageManager.getApplicationInfo(app.packageName)
                ?: return null
            val appInfo = ApplicationInfo(baseInfo).apply {
                sourceDir = app.apkPath
                publicSourceDir = app.apkPath
                dataDir = app.dataDir
                nativeLibraryDir = app.libDir
                processName = app.packageName
                targetSdkVersion = app.targetSdkVersion
                if (app.splitApkPaths.isNotEmpty()) {
                    splitSourceDirs = app.splitApkPaths.toTypedArray()
                    splitPublicSourceDirs = app.splitApkPaths.toTypedArray()
                    // LoadedApk walks splitNames in lockstep with
                    // splitSourceDirs; the VPMS copy leaves it null,
                    // which NPEs inside LoadedApk.getClassLoader for
                    // split guests. Prefer the install-parse names.
                    splitNames = serviceManager.packageManager
                        .getRecord(app.packageName)?.packageInfo?.splitNames
                        ?: app.splitApkPaths.map { path ->
                            path.substringAfterLast('/')
                                .removeSuffix(".apk")
                                .substringAfter("_split_", "")
                        }.toTypedArray()
                }
                uid = android.os.Process.myUid()
                deviceProtectedDataDir = dataDir
                // v142: the v136 framework-info spoof is REVERTED. A
                // synthetic sourceDir breaks native code that libart loads
                // without GOT patching (libart lives in a linker namespace
                // the patch pass never enumerates — v139/v141): its dex
                // opens bypass the redirect (empty DexPathList) and its
                // direct native loads crash in .so init. So the framework
                // LoadedApk keeps the real sandbox paths above (v135
                // behavior, bootable), while the Java-layer getters
                // (VirtualContext/PM/VAM, v135) still report synthetic
                // paths — the face tap now tests the Java-level path
                // hypothesis against a working guest.
                // LoadedApk.makeApplication() instantiates
                // ApplicationInfo.className; the VPMS copies leave it
                // null, which silently substitutes a default
                // android.app.Application — a packer's stub Application
                // would then never run at all. The install parse stored
                // the real manifest application class on the VirtualApp.
                if (app.applicationClassName != null) {
                    className = app.applicationClassName
                }
            }
            val atClass = Class.forName("android.app.ActivityThread")
            val activityThread = atClass.getMethod("currentActivityThread").invoke(null)
                ?: return null
            val compatClass = Class.forName("android.content.res.CompatibilityInfo")
            val compat = compatClass.getField("DEFAULT_COMPATIBILITY_INFO").get(null)
            GuestBreadcrumb.log(
                "createFrameworkLoadedApk call pkg=${app.packageName} appInfo.packageName=" +
                    appInfo.packageName + " appInfo.className=" + appInfo.className +
                    " appInfo.sourceDir=" + appInfo.sourceDir
            )
            val loadedApk = atClass
                .getMethod("getPackageInfoNoCheck", ApplicationInfo::class.java, compatClass)
                .invoke(activityThread, appInfo, compat)
                ?: return null
            GuestBreadcrumb.log(
                "createFrameworkLoadedApk result " + loadedApkWitness(loadedApk) +
                    mPackagesWitness(app.packageName)
            )
            frameworkLoadedApks[app.instanceId] = loadedApk
            loadedApk
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Framework LoadedApk failed for ${app.packageName}")
            null
        }
    }

    /**
     * v52 diagnostic: compact identity summary of a framework LoadedApk
     * (identity hash + package fields + whether an Application is
     * already attached). Never throws.
     */
    private fun loadedApkWitness(loadedApk: Any): String {
        fun field(name: String): Any? = try {
            var cls: Class<*>? = loadedApk.javaClass
            var f: java.lang.reflect.Field? = null
            while (cls != null && f == null) {
                f = try {
                    cls.getDeclaredField(name)
                } catch (e: NoSuchFieldException) {
                    null
                }
                if (f == null) cls = cls.superclass
            }
            f?.apply { isAccessible = true }?.get(loadedApk)
        } catch (e: Exception) {
            null
        }
        val ai = field("mApplicationInfo") as? ApplicationInfo
        val app = field("mApplication")
        val appDesc = if (app == null) {
            "null"
        } else {
            app.javaClass.name + "#" + System.identityHashCode(app)
        }
        return "loadedApk=#" + System.identityHashCode(loadedApk) +
            " mPackageName=" + field("mPackageName") +
            " ai.packageName=" + ai?.packageName +
            " ai.sourceDir=" + ai?.sourceDir +
            " mApplication=" + appDesc
    }

    /**
     * v52 diagnostic: identity hashes of the LoadedApks currently
     * registered in ActivityThread.mPackages under the guest and host
     * package names. Never throws.
     */
    private fun mPackagesWitness(guestPkg: String): String {
        return try {
            val atClass = Class.forName("android.app.ActivityThread")
            val activityThread = atClass.getMethod("currentActivityThread").invoke(null)
                ?: return " mPackages=<no ActivityThread>"
            var cls: Class<*>? = atClass
            var f: java.lang.reflect.Field? = null
            while (cls != null && f == null) {
                f = try {
                    cls.getDeclaredField("mPackages")
                } catch (e: NoSuchFieldException) {
                    null
                }
                if (f == null) cls = cls.superclass
            }
            f?.isAccessible = true
            val packages = f?.get(activityThread) as? android.util.ArrayMap<*, *>
                ?: return " mPackages=<null>"
            fun refHash(key: String): Int {
                val ref = packages[key] as? java.lang.ref.WeakReference<*>
                val obj = ref?.get() ?: return -1
                return System.identityHashCode(obj)
            }
            " mPackages[guest]=#" + refHash(guestPkg) +
                " mPackages[host]=#" + refHash(context.packageName)
        } catch (e: Exception) {
            " mPackages=<error ${e.javaClass.simpleName}>"
        }
    }

    private fun createFrameworkClassLoader(app: VirtualApp): ClassLoader? {
        return try {
            val loadedApk = createFrameworkLoadedApk(app) ?: return null
            // v143: the v140 preset is REMOVED. It built a PathClassLoader
            // whose parent was the engine's own (host) classloader, and
            // v142 died on a same-package cross-loader split at the first
            // AppCompat UI (privacy dialog): AppCompatDrawableManager from
            // the shell's in-memory dex could not access package-private
            // ResourceManagerInternal.getDrawable, i.e. the two classes
            // landed under different loaders (IllegalAccessError). The
            // preset was only ever needed because the framework sourceDir
            // was synthetic (v139: ART dex opens bypass the redirect); v142
            // restored the framework sourceDir to the real sandbox APK, so
            // the framework's own getClassLoader() below now builds a
            // normal DexPathList — the v135 loader configuration, which
            // had no such split. If the dialog survives, the preset was
            // the splitter; if the same error recurs, the split is in the
            // in-memory dex loading itself.
            val classLoader = loadedApk.javaClass.getMethod("getClassLoader")
                .invoke(loadedApk) as? ClassLoader
                ?: return null
            Timber.tag(TAG).i(
                "Framework LoadedApk classloader for ${app.packageName}: " +
                    "${classLoader.javaClass.name}, parents: ${parentChainOf(classLoader)}"
            )
            classLoader
        } catch (e: Exception) {
            Timber.tag(TAG).w(
                e,
                "Framework classloader failed for ${app.packageName}, falling back to manual"
            )
            null
        }
    }

    private fun parentChainOf(classLoader: ClassLoader): String {
        val names = mutableListOf<String>()
        var current: ClassLoader? = classLoader.parent
        while (current != null) {
            names.add(current.javaClass.simpleName)
            current = current.parent
        }
        return names.joinToString(" -> ")
    }

    /**
     * Get a VirtualApp by instance ID.
     */
    fun findApp(instanceId: String): VirtualApp? =
        _installedApps.value.find { it.instanceId == instanceId }

    /**
     * Get a VirtualApp by package name.
     */
    fun findAppByPackage(packageName: String): VirtualApp? =
        _installedApps.value.find { it.packageName == packageName }

    /**
     * Find a VirtualApp by matching its ClassLoader.
     * Used to resolve the instanceId when an Activity is created by internal
     * navigation (e.g., Play Store launching AssetBrowserActivity internally)
     * without going through the stub system.
     */
    fun findAppByClassLoader(classLoader: ClassLoader): VirtualApp? {
        for ((instanceId, cl) in classLoaders) {
            if (cl === classLoader) {
                return findApp(instanceId)
            }
        }
        return null
    }

    /**
     * Check if a package name belongs to a virtual app.
     * Delegates to VirtualPackageManagerService (real service).
     */
    fun isVirtualPackage(packageName: String): Boolean =
        serviceManager.isVirtualPackage(packageName)

    /**
     * Resolve an activity name to its real class, handling activity-aliases.
     * If the named activity is an alias (has targetActivity set), returns the real target.
     * Otherwise returns the original name unchanged.
     */
    fun resolveActivityAlias(packageName: String, activityName: String): String =
        serviceManager.packageManager.resolveActivityClass(packageName, activityName)

    /**
     * Get the instance ID for a running app by process slot.
     */
    fun getInstanceIdForSlot(slot: Int): String? =
        runningApps.entries.find { it.value == slot }?.key

    /**
     * Convenience: get list of installed apps (snapshot).
     * Used by ViewModels that don't observe the StateFlow.
     */
    fun getInstalledApps(): List<VirtualApp> = _installedApps.value

    /**
     * Convenience: get current engine status.
     */
    fun getEngineStatus(): EngineStatus = _status.value

    /**
     * Launch a virtual app by package name (finds first matching instance).
     */
    fun launchAppByPackage(packageName: String): VmResult<Unit> {
        val app = findAppByPackage(packageName)
            ?: return VmResult.Error("No virtual app found for package: $packageName")
        return launchApp(app.instanceId)
    }

    /**
     * Uninstall a virtual app by package name (removes first matching instance).
     */
    fun uninstallAppByPackage(packageName: String): VmResult<Unit> {
        val app = findAppByPackage(packageName)
            ?: return VmResult.Error("No virtual app found for package: $packageName")
        return uninstallApp(app.instanceId)
    }

    // === Private helpers ===

    private fun ensureInitialized() {
        if (_status.value == EngineStatus.READY) return

        if (_status.value == EngineStatus.INITIALIZING) {
            // Wait for init to complete (max 30s)
            val startTime = System.currentTimeMillis()
            while (_status.value == EngineStatus.INITIALIZING) {
                if (System.currentTimeMillis() - startTime > 30_000) break
                Thread.sleep(100)
            }
        }

        check(_status.value == EngineStatus.READY) {
            "VirtualEngine not initialized (status=${_status.value}). " +
            "Call initialize() first or wait for async init to complete."
        }
    }

    private fun createVirtualDirectories() {
        virtualRoot = File(context.filesDir, VirtualConstants.VIRTUAL_DIR)
        apksDir = File(virtualRoot, VirtualConstants.VIRTUAL_APKS_DIR)
        dataDir = File(virtualRoot, VirtualConstants.VIRTUAL_DATA_DIR)

        virtualRoot.mkdirs()
        apksDir.mkdirs()
        dataDir.mkdirs()

        File(virtualRoot, VirtualConstants.VIRTUAL_SNAPSHOTS_DIR).mkdirs()

        Timber.tag(TAG).d("Virtual directories created at: ${virtualRoot.absolutePath}")
    }

    private fun copyApkToVirtualStorage(
        apkPath: String,
        instanceId: String,
        packageName: String
    ): String {
        val sourceFile = File(apkPath)
        val destFile = File(apksDir, "${instanceId}.apk")
        sourceFile.copyTo(destFile, overwrite = true)

        // Android 8.0+ (API 26+) rejects loading APKs/DEX files that are writable.
        // DexFile.openDexFileNative throws SecurityException: "Writable dex file is not allowed."
        // Strip all write permissions so the file is read-only (owner r--, group r--, other r--).
        destFile.setWritable(false, false)   // remove write for everyone
        destFile.setReadable(true, false)    // ensure readable by all
        destFile.setExecutable(false, false) // APKs don't need execute bit

        createApkGuardLink(destFile)

        Timber.tag(TAG).d("APK copied to: ${destFile.absolutePath}")
        return destFile.absolutePath
    }

    /**
     * v81 (launch104 fix): some guest SDKs delete the app's own APK
     * copy during init — ZWRisk.setup() unlinks the path it reads
     * from ApplicationInfo.sourceDir while running inside the agree
     * flow. On a real device that unlink targets /data/app and fails
     * on permissions; here the copy sits in same-uid storage, so it
     * succeeds and the next activity launch dies with Resources
     * NPE ("Failed to open APK"). Keep a hard link to every copied
     * APK in .apk_guard/, a directory name the guest never sees:
     * unlinking the visible name leaves the inode alive, and the
     * in-process watchdog (ActivityThreadHook) re-links the name
     * back within milliseconds. A hard link costs no extra space.
     */
    internal fun createApkGuardLink(apkFile: File) {
        try {
            val guardDir = File(virtualRoot, ".apk_guard")
            if (!guardDir.exists()) guardDir.mkdirs()
            val guardFile = File(guardDir, apkFile.name)
            if (guardFile.exists()) guardFile.delete()
            android.system.Os.link(
                apkFile.absolutePath, guardFile.absolutePath
            )
            Timber.tag(TAG).d("APK guard link: ${guardFile.absolutePath}")
        } catch (t: Throwable) {
            Timber.tag(TAG).w(
                "APK guard link failed for ${apkFile.name}: ${t.message}"
            )
        }
    }

    /**
     * Discover split APKs for an installed host app.
     *
     * Split APKs (e.g., split_config.arm64_v8a.apk) contain native libraries
     * that are essential for apps like Unity games. Without these, the app
     * crashes with UnsatisfiedLinkError (e.g., "libmain.so not found").
     *
     * Discovery methods:
     * 1. Check the parent directory of the base APK for split_*.apk files
     * 2. Query the host PackageManager for ApplicationInfo.splitSourceDirs
     */
    private fun discoverSplitApks(baseApkPath: String, packageName: String): List<String> {
        val splits = mutableListOf<String>()

        // Method 1: Check parent directory for split_*.apk files
        // When installing from /data/app/.../base.apk, splits are siblings
        val parentDir = File(baseApkPath).parentFile
        if (parentDir != null && parentDir.isDirectory) {
            try {
                parentDir.listFiles()?.filter {
                    it.name.startsWith("split_") && it.name.endsWith(".apk") && it.isFile
                }?.forEach { splits.add(it.absolutePath) }
            } catch (e: Exception) {
                Timber.tag(TAG).d("Could not scan parent dir for splits: ${e.message}")
            }
        }

        // Method 2: Get from host PackageManager's ApplicationInfo.splitSourceDirs
        // On Android 11+, listFiles() often fails due to directory access restrictions,
        // but PM-reported paths are still directly readable via open().
        if (splits.isEmpty()) {
            try {
                @Suppress("DEPRECATION")
                val appInfo = context.packageManager.getApplicationInfo(packageName, 0)
                appInfo.splitSourceDirs?.forEach { splitPath ->
                    // Don't use File.exists() — on Android 11+ stat() may fail due to
                    // SELinux even though the file is readable. Trust PM-reported paths.
                    if (splitPath !in splits) {
                        splits.add(splitPath)
                    }
                }
            } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
                // Package not installed on host — no splits to discover
            } catch (e: Exception) {
                Timber.tag(TAG).d("Could not get split paths from PM: ${e.message}")
            }
        }

        // Method 3: Construct known ABI split paths from base APK directory
        // Play Store app bundles use predictable naming: split_config.{abi}.apk
        if (splits.isEmpty() && parentDir != null) {
            val knownAbis = listOf("arm64_v8a", "armeabi_v7a", "x86_64", "x86")
            for (abi in knownAbis) {
                val splitFile = File(parentDir, "split_config.$abi.apk")
                try {
                    java.util.zip.ZipFile(splitFile).use { /* accessible */ }
                    splits.add(splitFile.absolutePath)
                    Timber.tag(TAG).d("Found ABI split via probe: ${splitFile.name}")
                } catch (_: Exception) { /* not accessible, skip */ }
            }
        }

        if (splits.isNotEmpty()) {
            Timber.tag(TAG).i("Found ${splits.size} split APKs: ${splits.map { File(it).name }}")
        } else {
            Timber.tag(TAG).w("No split APKs found for $packageName (base=$baseApkPath)")
        }

        return splits
    }

    private fun updateAppState(instanceId: String, transform: (VirtualApp) -> VirtualApp) {
        val current = _installedApps.value.toMutableList()
        val index = current.indexOfFirst { it.instanceId == instanceId }
        if (index >= 0) {
            current[index] = transform(current[index])
            _installedApps.value = current
        }
    }

    private fun saveVirtualApp(app: VirtualApp) {
        val file = File(virtualRoot, "apps/${app.instanceId}.json")
        file.parentFile?.mkdirs()
        val gson = com.google.gson.Gson()
        val data = VirtualAppData.fromVirtualApp(app)
        file.writeText(gson.toJson(data))
    }

    private fun deleteSavedApp(instanceId: String) {
        File(virtualRoot, "apps/${instanceId}.json").delete()
    }

    private fun loadInstalledApps() {
        val appsDir = File(virtualRoot, "apps")
        if (!appsDir.exists()) return

        val apps = mutableListOf<VirtualApp>()
        appsDir.listFiles()?.filter { it.extension == "json" }?.forEach { file ->
            try {
                val json = file.readText()
                val app = parseAppJson(json)
                if (app != null && File(app.apkPath).exists()) {
                    // Reload icon from APK since Drawable is not serialized
                    var appWithIcon = reloadIconFromApk(app)

                    // Re-extract native libs if missing (fixes previously broken installs)
                    val dataRoot = File(virtualRoot, "data")
                    val reResult = NativeLibManager.reExtractIfMissing(
                        apkPath = appWithIcon.apkPath,
                        splitApkPaths = appWithIcon.splitApkPaths,
                        instanceId = appWithIcon.instanceId,
                        dataRoot = dataRoot
                    )
                    if (reResult != null) {
                        appWithIcon = appWithIcon.copy(
                            libDir = reResult.libDir,
                            librarySearchPath = reResult.librarySearchPath,
                            primaryAbi = reResult.selectedAbi
                        )
                        saveVirtualApp(appWithIcon)
                    }

                    apps.add(appWithIcon)
                    processManager.allocateSlot(appWithIcon.instanceId)

                    // Re-register in VPMS on load (lightweight, from disk)
                    serviceManager.packageManager.registerPackageFromDisk(appWithIcon)

                    // Re-initialize permissions and auto-grant all on reload
                    serviceManager.permissionManager.initializePermissions(
                        packageName = appWithIcon.packageName,
                        requestedPermissions = appWithIcon.requestedPermissions,
                        overrides = appWithIcon.permissionOverrides
                    )
                    serviceManager.permissionManager.grantAllPermissions(appWithIcon.packageName)

                    // Re-register with Binder proxies
                    if (::binderProxyManager.isInitialized) {
                        binderProxyManager.registerVirtualApp(appWithIcon)
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Failed to load app from: ${file.name}")
            }
        }

        _installedApps.value = apps
        Timber.tag(TAG).d("Loaded ${apps.size} installed apps")
    }

    // NOTE: GMS auto-install has been removed. USBTool now uses a Hybrid GMS Bridge
    // that proxies guest app GMS calls to the host device's real Google Play Services
    // without copying GMS APKs into the virtual environment.
    // See: core/services/gms/GmsBinderBridge.kt

    private fun parseAppJson(json: String): VirtualApp? {
        return try {
            val gson = com.google.gson.Gson()
            gson.fromJson(json, VirtualAppData::class.java)?.toVirtualApp()
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "JSON parse error")
            null
        }
    }

    /**
     * Reload the app icon from the APK file on disk.
     * Icons are Drawable (not serializable), so they are lost after JSON round-trip.
     * This uses PackageManager.getPackageArchiveInfo() which is fast and reliable.
     */
    private fun reloadIconFromApk(app: VirtualApp): VirtualApp {
        if (app.icon != null) return app
        return try {
            val pm = context.packageManager
            val info = pm.getPackageArchiveInfo(app.apkPath, 0)
            if (info?.applicationInfo != null) {
                info.applicationInfo!!.sourceDir = app.apkPath
                info.applicationInfo!!.publicSourceDir = app.apkPath
                val icon = pm.getApplicationIcon(info.applicationInfo!!)
                app.copy(icon = icon)
            } else {
                app
            }
        } catch (e: Exception) {
            Timber.tag(TAG).d("Failed to reload icon for ${app.packageName}: ${e.message}")
            app
        }
    }

    // ==================== ActivityThreadHook Helper Methods ====================

    /**
     * Ensure the guest app's Application class has been created and initialized.
     * This MUST run before any Activity is launched for the guest app.
     *
     * The boot sequence mirrors real Android:
     * 1. Create ClassLoader (already done by getOrCreateClassLoader)
     * 2. Create VirtualContext for the Application
     * 3. Instantiate the Application subclass via ClassLoader
     * 4. Install ContentProviders (BEFORE onCreate!)
     * 5. Call Application.attachBaseContext()
     * 6. Call Application.onCreate()
     */
    /**
     * Rewrite ActivityThread's bind-data process name to the guest's.
     * The stub process was bound by AMS under com.ssai.usbtool.app:pN, and
     * ActivityThread.currentProcessName() reads exactly this field —
     * the last place the stub identity remains visible to guest code
     * after the kernel-comm and argv0 renames.
     */
    private fun rewriteBoundProcessName(guestProcessName: String) {
        val atClass = Class.forName("android.app.ActivityThread")
        val activityThread = atClass.getMethod("currentActivityThread").invoke(null) ?: return
        val boundField = atClass.getDeclaredField("mBoundApplication")
        boundField.isAccessible = true
        val bound = boundField.get(activityThread) ?: return
        val nameField = bound.javaClass.getDeclaredField("processName")
        nameField.isAccessible = true
        nameField.set(bound, guestProcessName)
        val readBack = atClass.getMethod("currentProcessName").invoke(null) as? String
        Timber.tag(TAG).i("AppBindData.processName rewritten to $guestProcessName (readback: $readBack)")
    }

    fun ensureGuestApplicationBooted(instanceId: String, packageName: String, apkPath: String) {
        // Skip if already booted
        if (applicationManager.getApplication(instanceId) != null) {
            Timber.tag(TAG).d("Guest Application already booted for $instanceId")
            return
        }

        Timber.tag(TAG).i("Booting guest Application for $instanceId ($packageName)")

        try {
            // Get the app metadata
            val app = findApp(instanceId) ?: run {
                Timber.tag(TAG).w("App not found for $instanceId, skipping Application boot")
                return
            }

            // Get or create ClassLoader
            val classLoader = getOrCreateClassLoader(instanceId, apkPath)

            // Create a VirtualContext for the Application
            val virtualContext = com.ssai.usbtool.core.sandbox.VirtualContext(
                base = context,
                instanceId = instanceId,
                guestPackageName = packageName,
                sandboxManager = sandboxManager
            )
            virtualContext.setGuestClassLoader(classLoader)

            // Set binder interceptor for GMS binder proxying on bindService()
            setupBinderInterceptor(virtualContext, instanceId, packageName)

            // CRITICAL: Create and inject guest Resources BEFORE Application boot.
            // Without this, guest code calling context.getString(R.string.foo) or
            // ContentProvider.onCreate() -> context.getString() will look up resource IDs
            // in the HOST's resource table, causing Resources$NotFoundException for IDs
            // like 0x7f120025 that only exist in the guest APK.
            try {
                val guestResources = resourceManager.createResourcesForApp(
                    context = context,
                    apkPath = apkPath,
                    splitApkPaths = app.splitApkPaths.ifEmpty { null },
                    libDir = getNativeLibDir(instanceId),
                    classLoader = classLoader,
                    instanceId = instanceId
                )
                if (guestResources != null) {
                    virtualContext.setGuestResources(guestResources)
                    Timber.tag(TAG).d("Guest Resources injected for $instanceId")
                } else {
                    Timber.tag(TAG).w("Failed to create guest Resources for $instanceId — resource lookups may fail")
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Error creating guest Resources for $instanceId")
            }

            // Get Application class name from parsed APK metadata
            val applicationClassName = app.applicationClassName

            // Get ContentProvider info for auto-init
            val providerNames = app.providers
            val providerAuthorities = mutableMapOf<String, String>()
            // Build authority map from VPMS
            for (providerName in providerNames) {
                val authority = serviceManager.packageManager
                    .getProviderAuthority(packageName, providerName)
                if (authority != null) {
                    providerAuthorities[providerName] = authority
                }
            }

            // v39: also recover each provider's manifest meta-data. The
            // records VPMS keeps for disk-loaded apps carry bare
            // ProviderInfo objects (name only), so parse the APK itself —
            // the same getPackageArchiveInfo route ApkParser uses at
            // install time. Providers reading their meta-data during
            // attachInfo/onCreate need it present on the ProviderInfo.
            val providerMetaData = mutableMapOf<String, Bundle>()
            try {
                val archiveInfo = context.packageManager.getPackageArchiveInfo(
                    apkPath,
                    PackageManager.GET_PROVIDERS or PackageManager.GET_META_DATA
                )
                archiveInfo?.providers?.forEachIndexed { idx, parsed ->
                    parsed.metaData?.let { providerMetaData[parsed.name] = it }
                    if (providerAuthorities[parsed.name] == null &&
                        !parsed.authority.isNullOrEmpty()
                    ) {
                        providerAuthorities[parsed.name] = parsed.authority
                    }
                    // v118 probe (read-only): system ProviderInfo
                    // fields per provider, in system-parser order, so
                    // the install order in breadcrumb can be compared
                    // against it — and so initOrder / permissions /
                    // multiprocess / processName are on record instead
                    // of assumed. Logged to breadcrumb (buffered
                    // before attachFile) and to Timber, since this
                    // block may run before the breadcrumb file is
                    // attached in some paths.
                    val fields = "v118-provider-fields idx=$idx " +
                        "name=${parsed.name} authority=${parsed.authority} " +
                        "initOrder=${parsed.initOrder} " +
                        "exported=${parsed.exported} enabled=${parsed.enabled} " +
                        "multiprocess=${parsed.multiprocess} " +
                        "readPermission=${parsed.readPermission} " +
                        "writePermission=${parsed.writePermission} " +
                        "process=${parsed.processName}"
                    try {
                        com.ssai.usbtool.core.virtualization.lifecycle.GuestBreadcrumb.log(fields)
                    } catch (_: Throwable) {
                    }
                    Timber.tag(TAG).i("%s", fields)
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "Provider meta-data parse failed for $packageName")
            }

            // Arm native /proc/self spoofing (cmdline/maps/comm) for this
            // guest BEFORE its Application runs. Packer shells read /proc
            // inside attachBaseContext — i.e. during bindApplication below —
            // and nativeSpoofProcSelf was previously never called at all,
            // which left the native spoof state (package name) empty and
            // every /proc spoof check inert.
            try {
                nativeHookBridge.spoofProcSelf(android.os.Process.myPid(), packageName)
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "spoofProcSelf failed for $packageName")
            }

            // Arm the seccomp raw-syscall diagnostic: anything in this
            // process that issues path syscalls via direct svc (past
            // every libc hook) gets attributed and logged.
            try {
                val diagLog = File(context.filesDir, "seccomp-diag.log")
                nativeHookBridge.armSeccompDiag(diagLog.absolutePath)
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "armSeccompDiag failed for $packageName")
            }

            // Capture the stub slot BEFORE any renaming below:
            // VirtualCallerResolver parses the slot out of the process
            // name to route PM calls; once the name becomes the guest's,
            // the slot must come from this cache or PM isolation breaks.
            VirtualCallerResolver.cacheProcessSlotFromCurrentName()

            // Take on the guest's process identity at the source:
            // rename this stub process (kernel comm via prctl, argv0)
            // to the guest's process name BEFORE its Application runs.
            // The /proc spoofs above only fix what hooked readers see;
            // the process name is also visible on channels no read hook
            // can reach (framework process-name queries, the guest's
            // own children inspecting their parent, ps/task views).
            try {
                // Process.setArgV0 is @hide — invoke reflectively (the
                // runtime's hidden-API bypass makes it callable)
                val setArgV0 = android.os.Process::class.java
                    .getMethod("setArgV0", String::class.java)
                setArgV0.invoke(null, packageName)
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "setArgV0 failed for $packageName")
            }
            try {
                nativeHookBridge.setProcessName(packageName)
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "setProcessName failed for $packageName")
            }

            // Rewrite the framework's own record of this process's name:
            // ActivityThread.currentProcessName() (and with it
            // Application.getProcessName()) reads
            // mBoundApplication.processName, which still says
            // com.ssai.usbtool.app:pN after the kernel/argv renames above.
            // The slot was cached above, so this cannot break the PM
            // caller's slot resolution.
            try {
                rewriteBoundProcessName(packageName)
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "rewriteBoundProcessName failed for $packageName")
            }

            // v57: for the CM guest, suspend /proc/self spoofing for
            // the duration of the bind. Its SecNeo mini-linker stub
            // (libDexHelper.so) parses the real /proc/self/maps in its
            // constructor — which runs inside bindApplication below,
            // when the shell's attach triggers System.loadLibrary —
            // to resolve libc symbols and locate its own image; the
            // spoofed maps silently abort its registration chain and
            // every H.* native stays unregistered. The stub is also
            // exempt from GOT late-patching on the native side.
            val suspendSpoof =
                packageName == "com.greenpoint.android.mc10086.activity"
            if (suspendSpoof) {
                try {
                    nativeHookBridge.setProcSpoofSuspended(true)
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "setProcSpoofSuspended(true) failed")
                }
            }
            // v137: path-fidelity redirections now live in
            // getOrCreateClassLoader (before any classloader build);
            // the v135 bind-time registration here was too late (the
            // framework classloader was already built+cached empty).
            try {
                // Boot the Application via ApplicationManager
                applicationManager.bindApplication(
                    instanceId = instanceId,
                    packageName = packageName,
                    applicationClassName = applicationClassName,
                    apkPath = apkPath,
                    classLoader = classLoader,
                    virtualContext = virtualContext,
                    providerNames = providerNames,
                    providerAuthorities = providerAuthorities,
                    providerMetaData = providerMetaData,
                    frameworkLoadedApk = frameworkLoadedApks[instanceId]
                )
            } finally {
                if (suspendSpoof) {
                    try {
                        nativeHookBridge.setProcSpoofSuspended(false)
                    } catch (e: Exception) {
                        Timber.tag(TAG).w(
                            e, "setProcSpoofSuspended(false) failed"
                        )
                    }
                }
            }

            Timber.tag(TAG).i("Guest Application booted successfully for $instanceId")
        } catch (e: UnsatisfiedLinkError) {
            // Native library failed to load — mark as booted anyway to prevent
            // infinite crash loops (the guest process keeps restarting otherwise).
            // The guest app will likely malfunction but at least the system won't loop.
            Timber.tag(TAG).e(e, "Native library load failed for $instanceId — guest app may not work correctly")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to boot guest Application for $instanceId")
        }
    }

    /**
     * Get the native library directory for a guest app instance.
     */
    fun getNativeLibDir(instanceId: String): String? {
        val app = findApp(instanceId) ?: return null
        val libDir = File(virtualRoot, "data/${app.instanceId}/lib")
        return if (libDir.exists()) libDir.absolutePath else null
    }

    /**
     * Get the data directory for a guest app instance.
     */
    fun getDataDir(instanceId: String): String? {
        val dataPath = File(virtualRoot, "data/$instanceId")
        return if (dataPath.exists()) dataPath.absolutePath else null
    }

    /**
     * Get the VirtualResourceManager.
     */
    fun getResourceManager(): VirtualResourceManager? {
        return resourceManager
    }

    /**
     * Get the theme resource ID for a guest app's activity.
     * Returns activity-specific theme if set, falls back to application theme.
     */
    fun getThemeResId(instanceId: String): Int {
        val app = findApp(instanceId) ?: return 0
        return app.metaData["_nextvm_theme_res_id"]?.toIntOrNull() ?: 0
    }

    /**
     * Get theme resource ID from parsed manifest via PackageManagerProxy.
     * Returns activity-specific theme, falls back to application theme.
     */
    fun getActivityThemeResId(packageName: String, activityName: String): Int {
        if (!::binderProxyManager.isInitialized) return 0
        return binderProxyManager.getActivityTheme(packageName, activityName)
    }

    /**
     * Get the guest Application instance for a virtual app.
     */
    fun getGuestApplication(instanceId: String): android.app.Application? {
        return applicationManager.getApplication(instanceId)
    }

    /**
     * Wrap an Activity's base context with VirtualContext for file isolation.
     *
     * CRITICAL: We must wrap the Activity's CURRENT base context (not the Activity itself)
     * to avoid circular ContextWrapper delegation that causes StackOverflowError
     * in getDisplay()/getDisplayNoVerify() calls.
     */
    fun wrapActivityContext(
        activity: android.app.Activity,
        instanceId: String,
        packageName: String
    ) {
        try {
            // Get the Activity's current base context (the real ContextImpl)
            val mBaseField = android.content.ContextWrapper::class.java.getDeclaredField("mBase")
            mBaseField.isAccessible = true
            val currentBase = mBaseField.get(activity) as? android.content.Context
                ?: run {
                    Timber.tag(TAG).w("Activity base context is null for $instanceId")
                    return
                }

            // Don't double-wrap
            if (currentBase is com.ssai.usbtool.core.sandbox.VirtualContext) {
                Timber.tag(TAG).d("Activity already wrapped for $instanceId")
                return
            }

            val virtualContext = com.ssai.usbtool.core.sandbox.VirtualContext(
                base = currentBase,  // wrap the base, NOT the activity
                instanceId = instanceId,
                guestPackageName = packageName,
                sandboxManager = sandboxManager
            )

            // Set binder interceptor for GMS binder proxying on bindService()
            setupBinderInterceptor(virtualContext, instanceId, packageName)

            // Set guest ClassLoader on the virtual context
            val guestCl = getClassLoader(instanceId)
            if (guestCl != null) {
                virtualContext.setGuestClassLoader(guestCl)
            }

            // CRITICAL: Set guest Application so getApplicationContext() returns the
            // guest Application, NOT the host NextVmApplication. Without this:
            // 1. Hilt/Dagger apps crash: they cast getApplicationContext() to their
            //    Application subclass which implements GeneratedComponentManager
            // 2. GMS "Unknown calling package" errors: GMS SDK calls
            //    getApplicationContext().bindService() which bypasses VirtualContext's
            //    bindService() override → binder not wrapped → package not rewritten
            val guestApp = getGuestApplication(instanceId)
            if (guestApp != null) {
                virtualContext.setGuestApplication(guestApp)
            }

            // Replace the Activity's base context
            mBaseField.set(activity, virtualContext)
            Timber.tag(TAG).d("VirtualContext wrapped for activity $instanceId")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to wrap activity context for $instanceId")
        }
    }

    /**
     * Internal data class for JSON serialization.
     * Includes all Android 16 framework fields.
     */
    private data class VirtualAppData(
        val packageName: String = "",
        val appName: String = "",
        val versionName: String = "",
        val versionCode: Long = 0,
        val apkPath: String = "",
        val instanceId: String = "",
        val processSlot: Int = -1,
        val installedAt: Long = 0,
        val is64Bit: Boolean = true,
        val mainActivity: String? = null,
        val activities: List<String> = emptyList(),
        val services: List<String> = emptyList(),
        val providers: List<String> = emptyList(),
        val receivers: List<String> = emptyList(),
        // Android 16 framework fields
        val minSdkVersion: Int = 1,
        val targetSdkVersion: Int = 35,
        val isMultiArch: Boolean = false,
        val use32bitAbi: Boolean = false,
        val extractNativeLibs: Boolean = true,
        val useEmbeddedDex: Boolean = false,
        val isDebuggable: Boolean = false,
        val installLocation: Int = 0,
        val pageSizeCompat: Int = 0,
        val splitApkPaths: List<String> = emptyList(),
        val splitNames: List<String> = emptyList(),
        val hasSplitApks: Boolean = false,
        val isolatedSplits: Boolean = false,
        val applicationClassName: String? = null,
        val requestedPermissions: List<String> = emptyList(),
        val nativeAbis: List<String> = emptyList(),
        val metaData: Map<String, String> = emptyMap(),
        val activityAliases: Map<String, String> = emptyMap(),
        val dataDir: String = "",
        val libDir: String = "",
        val librarySearchPath: String = "",
        val primaryAbi: String = "",
        val cacheDir: String = ""
    ) {
        fun toVirtualApp() = VirtualApp(
            packageName = packageName,
            appName = appName,
            versionName = versionName,
            versionCode = versionCode,
            apkPath = apkPath,
            instanceId = instanceId,
            processSlot = processSlot,
            installedAt = installedAt,
            is64Bit = is64Bit,
            mainActivity = mainActivity,
            activities = activities,
            services = services,
            providers = providers,
            receivers = receivers,
            minSdkVersion = minSdkVersion,
            targetSdkVersion = targetSdkVersion,
            isMultiArch = isMultiArch,
            use32bitAbi = use32bitAbi,
            extractNativeLibs = extractNativeLibs,
            useEmbeddedDex = useEmbeddedDex,
            isDebuggable = isDebuggable,
            installLocation = installLocation,
            pageSizeCompat = pageSizeCompat,
            splitApkPaths = splitApkPaths,
            splitNames = splitNames,
            hasSplitApks = hasSplitApks,
            isolatedSplits = isolatedSplits,
            applicationClassName = applicationClassName,
            requestedPermissions = requestedPermissions,
            nativeAbis = nativeAbis,
            metaData = metaData,
            activityAliases = activityAliases,
            dataDir = dataDir,
            libDir = libDir,
            librarySearchPath = librarySearchPath,
            primaryAbi = primaryAbi,
            cacheDir = cacheDir
        )

        companion object {
            fun fromVirtualApp(app: VirtualApp) = VirtualAppData(
                packageName = app.packageName,
                appName = app.appName,
                versionName = app.versionName,
                versionCode = app.versionCode,
                apkPath = app.apkPath,
                instanceId = app.instanceId,
                processSlot = app.processSlot,
                installedAt = app.installedAt,
                is64Bit = app.is64Bit,
                mainActivity = app.mainActivity,
                activities = app.activities,
                services = app.services,
                providers = app.providers,
                receivers = app.receivers,
                minSdkVersion = app.minSdkVersion,
                targetSdkVersion = app.targetSdkVersion,
                isMultiArch = app.isMultiArch,
                use32bitAbi = app.use32bitAbi,
                extractNativeLibs = app.extractNativeLibs,
                useEmbeddedDex = app.useEmbeddedDex,
                isDebuggable = app.isDebuggable,
                installLocation = app.installLocation,
                pageSizeCompat = app.pageSizeCompat,
                splitApkPaths = app.splitApkPaths,
                splitNames = app.splitNames,
                hasSplitApks = app.hasSplitApks,
                isolatedSplits = app.isolatedSplits,
                applicationClassName = app.applicationClassName,
                requestedPermissions = app.requestedPermissions,
                nativeAbis = app.nativeAbis,
                metaData = app.metaData,
                activityAliases = app.activityAliases,
                dataDir = app.dataDir,
                libDir = app.libDir,
                librarySearchPath = app.librarySearchPath,
                primaryAbi = app.primaryAbi,
                cacheDir = app.cacheDir
            )
        }
    }
}
