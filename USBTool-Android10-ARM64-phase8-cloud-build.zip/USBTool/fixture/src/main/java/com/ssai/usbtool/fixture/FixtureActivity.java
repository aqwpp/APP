package com.ssai.usbtool.fixture;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public final class FixtureActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView text = new TextView(this);
        text.setText("USBTool controlled runtime fixture\nAPI 29\nCustom Application + Activity + Service + Receiver + Provider");
        text.setPadding(32, 48, 32, 48);
        setContentView(text);
    }
}
