package com.ssai.usbtool.fixture;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** Manifest-only task semantics fixture; used to test metadata inspection. */
public final class FixtureSingleTaskActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setText("USBTool singleTask fixture");
        setContentView(view);
    }
}
