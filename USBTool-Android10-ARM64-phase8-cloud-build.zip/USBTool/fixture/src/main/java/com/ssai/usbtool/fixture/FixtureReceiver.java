package com.ssai.usbtool.fixture;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public final class FixtureReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Log.i("USBToolFixture", "FixtureReceiver.onReceive: " + intent.getAction());
    }
}
