package com.ssai.usbtool.fixture;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public final class FixtureIsolatedService extends Service {
    @Override public void onCreate() {
        super.onCreate();
        Log.i("USBToolFixture", "FixtureIsolatedService.onCreate");
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
