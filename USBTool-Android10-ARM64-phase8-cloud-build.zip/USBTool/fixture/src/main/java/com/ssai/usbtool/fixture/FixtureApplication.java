package com.ssai.usbtool.fixture;

import android.app.Application;
import android.util.Log;

public final class FixtureApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        Log.i("USBToolFixture", "FixtureApplication.onCreate");
    }
}
