@echo off
setlocal
cd /d %~dp0
gradle --no-daemon clean :app:assembleDebug :fixture:assembleDebug
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y app\build\outputs\apk\debug\app-debug.apk dist\USBTool-debug.apk
if errorlevel 1 exit /b 1
copy /Y fixture\build\outputs\apk\debug\fixture-debug.apk dist\USBTool-fixture-debug.apk
if errorlevel 1 exit /b 1
echo USBTool APK: dist\USBTool-debug.apk
echo Fixture APK: dist\USBTool-fixture-debug.apk
