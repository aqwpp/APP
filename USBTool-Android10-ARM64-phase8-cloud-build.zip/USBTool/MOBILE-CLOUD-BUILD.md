# USBTool 手机云端构建（GitHub Actions）

## 当前交付

本工程增加了 `.github/workflows/android-debug.yml`。GitHub Actions 云端 runner 会安装 JDK 17、Gradle 8.7、Android SDK Platform 35 / Build Tools 35.0.0，然后执行：

- `:app:testDebugUnitTest`
- `:app:assembleDebug`
- `:fixture:assembleDebug`

工作流会检查两个 APK 的 applicationId，并用 `apksigner` 确认 V1 签名有效、V2 签名关闭。成功后上传名为 `USBTool-Android10-ARM64-debug-apks` 的 artifact，保留 30 天。

Debug 密钥由 Android Gradle Plugin 在云端自动生成。它适合测试安装，不是稳定发布密钥。每次全新 runner 构建可能使用不同的 Debug key；升级安装时如签名不一致，先卸载旧测试版再安装新版本。

## 你只需在手机上做一次仓库导入

1. 在 ChatGPT 中连接 GitHub（如尚未连接）。
2. 在 GitHub 手机网页创建一个空仓库，例如 `USBTool-Android10-ARM64`。不要勾选自动创建 README、License 或 .gitignore。
3. 将本 ZIP 解压到手机文件管理器。注意上传的是 ZIP 内 `USBTool/` 文件夹的**内容**，包括 `.github` 隐藏目录、`app`、`fixture`、`build.gradle`、`settings.gradle` 等；不要多套一层 `USBTool/USBTool/`。
4. 将这些文件提交到仓库默认分支 `main`。
5. 打开仓库的 Actions 页面，选择 `USBTool Android Debug APK`，点 `Run workflow`。

## 下载 APK

工作流显示绿色成功后：
1. 打开该次 workflow run。
2. 滚动到页面底部的 Artifacts。
3. 下载 `USBTool-Android10-ARM64-debug-apks`。
4. 解压后得到：
   - `USBTool-debug.apk`
   - `USBTool-fixture-debug.apk`
   - `SHA256SUMS.txt`

## 失败时

打开失败的 workflow run，展开红色步骤，将完整错误日志复制回来。不要把 GitHub Personal Access Token、密码、keystore 或任何密钥贴到聊天里。

## 重要限制

- 本工作流只生成 Debug APK；不需要个人 JKS。
- `minSdk=29`，目标 SDK 为 35，ABI filter 配置为 `arm64-v8a`。若项目没有 NDK `.so` 文件，APK 不一定出现 `native-code: arm64-v8a` 标签；Java/Kotlin APK 本身可在 ARM64 Android 设备运行。ABI filter 约束的是本工程打包的 NDK ABI。
- APK 构建成功不代表任意第三方 APK 虚拟化运行已实现。当前 Activity/组件分析、代理、DexClassLoader 原型和进程 IPC 均有明确能力边界。
- 当前 workflow 只读仓库内容，不会自动推送代码、修改仓库设置或访问其他私有数据。
