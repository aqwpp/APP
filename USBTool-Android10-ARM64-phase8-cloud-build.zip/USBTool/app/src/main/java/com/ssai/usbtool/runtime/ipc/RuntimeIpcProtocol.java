package com.ssai.usbtool.runtime.ipc;

/** Message contract shared by the USBTool UI process and :runtime process. */
public final class RuntimeIpcProtocol {
    private RuntimeIpcProtocol() {}

    public static final int MSG_PING = 1;
    public static final int MSG_OPEN_SESSION = 2;
    public static final int MSG_CLOSE_SESSION = 3;
    public static final int MSG_REPLY = 100;

    public static final String KEY_STATUS = "status";
    public static final String KEY_PID = "pid";
    public static final String KEY_PROCESS_NAME = "process_name";
    public static final String KEY_PROFILE_ID = "profile_id";
    public static final String KEY_PACKAGE_NAME = "package_name";
    public static final String KEY_SESSION_ID = "session_id";
    public static final String KEY_ERROR = "error";
}
