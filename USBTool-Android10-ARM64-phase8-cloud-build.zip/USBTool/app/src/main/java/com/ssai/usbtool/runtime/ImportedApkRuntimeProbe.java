package com.ssai.usbtool.runtime;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;

import dalvik.system.DexClassLoader;

import java.io.File;
import java.lang.reflect.Method;

/**
 * Diagnostic-only probe for an imported APK.
 *
 * It checks whether the package metadata can be parsed, whether the declared
 * Application class can be resolved without initialization, and whether
 * archive resources can be opened through the legacy AssetManager.addAssetPath
 * reflection path.
 *
 * IMPORTANT:
 * - This does not instantiate Application or Activity.
 * - addAssetPath is hidden/non-SDK API and may be blocked by Android releases,
 *   device policy, or OEM implementation. Treat RESOURCE_* failures as expected.
 * - DexClassLoader loading is not an Android component runtime.
 * - Imported code must be trusted: a loaded class can execute code when later
 *   initialized or invoked, and shares the host UID/security permissions.
 */
public final class ImportedApkRuntimeProbe {
    private ImportedApkRuntimeProbe() {}

    public static ProbeResult inspect(Context context, File apkFile) {
        ProbeResult result = new ProbeResult();
        if (apkFile == null || !apkFile.isFile() || !apkFile.canRead()) {
            result.metadataStatus = "APK_MISSING_OR_UNREADABLE";
            return result;
        }

        result.apkPath = apkFile.getAbsolutePath();
        PackageManager pm = context.getPackageManager();
        PackageInfo packageInfo = pm.getPackageArchiveInfo(
                apkFile.getAbsolutePath(),
                PackageManager.GET_ACTIVITIES | PackageManager.GET_META_DATA);

        if (packageInfo == null || packageInfo.applicationInfo == null) {
            result.metadataStatus = "METADATA_PARSE_FAILED";
            return result;
        }

        ApplicationInfo appInfo = packageInfo.applicationInfo;
        appInfo.sourceDir = apkFile.getAbsolutePath();
        appInfo.publicSourceDir = apkFile.getAbsolutePath();
        result.packageName = packageInfo.packageName;
        result.applicationClass = appInfo.className;
        result.metadataStatus = "OK";

        String applicationClass = appInfo.className;
        if (applicationClass == null || applicationClass.trim().isEmpty()) {
            applicationClass = "android.app.Application";
        } else if (applicationClass.startsWith(".")) {
            applicationClass = packageInfo.packageName + applicationClass;
        } else if (applicationClass.indexOf('.') < 0) {
            applicationClass = packageInfo.packageName + "." + applicationClass;
        }

        File optimizedDir = new File(context.getCodeCacheDir(), "apk-probe-dex");
        if (!optimizedDir.exists() && !optimizedDir.mkdirs()) {
            result.dexStatus = "OPTIMIZED_DIR_CREATE_FAILED";
        } else {
            try {
                File nativeLibDir = new File(context.getFilesDir(), "apk-probe-native");
                if (!nativeLibDir.exists()) nativeLibDir.mkdirs();
                DexClassLoader loader = new DexClassLoader(
                        apkFile.getAbsolutePath(),
                        optimizedDir.getAbsolutePath(),
                        nativeLibDir.getAbsolutePath(),
                        context.getClassLoader());
                Class<?> resolved = Class.forName(applicationClass, false, loader);
                result.resolvedApplicationClass = resolved.getName();
                result.dexStatus = "CLASS_RESOLVED_NOT_INITIALIZED";
            } catch (ClassNotFoundException e) {
                result.dexStatus = "APPLICATION_CLASS_NOT_FOUND";
                result.dexDetail = e.toString();
            } catch (Throwable e) {
                result.dexStatus = "DEX_LOAD_ERROR";
                result.dexDetail = e.toString();
            }
        }

        probeResources(context, apkFile, packageInfo.packageName, result);
        return result;
    }

    private static void probeResources(Context context, File apkFile,
                                       String packageName, ProbeResult result) {
        AssetManager assets = null;
        try {
            assets = AssetManager.class.getDeclaredConstructor().newInstance();
            Method addAssetPath = AssetManager.class.getDeclaredMethod(
                    "addAssetPath", String.class);
            addAssetPath.setAccessible(true);
            Object cookie = addAssetPath.invoke(assets, apkFile.getAbsolutePath());
            if (!(cookie instanceof Integer) || ((Integer) cookie) == 0) {
                result.resourceStatus = "RESOURCE_PATH_REJECTED";
                return;
            }

            Resources host = context.getResources();
            Resources archiveResources = new Resources(
                    assets, host.getDisplayMetrics(), host.getConfiguration());
            int appNameId = archiveResources.getIdentifier(
                    "app_name", "string", packageName);
            if (appNameId != 0) {
                CharSequence appName = archiveResources.getText(appNameId);
                result.archiveAppName = appName == null ? null : appName.toString();
            }
            result.resourceStatus = appNameId == 0
                    ? "RESOURCE_ARCHIVE_OPENED_NO_APP_NAME"
                    : "RESOURCE_ARCHIVE_OPENED";
        } catch (Throwable e) {
            result.resourceStatus = "RESOURCE_ACCESS_BLOCKED_OR_FAILED";
            result.resourceDetail = e.toString();
        } finally {
            if (assets != null) {
                try { assets.close(); } catch (Throwable ignored) { }
            }
        }
    }

    public static final class ProbeResult {
        public String apkPath;
        public String packageName;
        public String applicationClass;
        public String metadataStatus = "NOT_RUN";
        public String dexStatus = "NOT_RUN";
        public String resolvedApplicationClass;
        public String dexDetail;
        public String resourceStatus = "NOT_RUN";
        public String archiveAppName;
        public String resourceDetail;

        public String toReport() {
            return "APK: " + value(apkPath)
                    + "\nPackage: " + value(packageName)
                    + "\nApplication class: " + value(applicationClass)
                    + "\nMetadata: " + metadataStatus
                    + "\nDEX: " + dexStatus
                    + "\nResolved class: " + value(resolvedApplicationClass)
                    + "\nDEX detail: " + value(dexDetail)
                    + "\nResources: " + resourceStatus
                    + "\nArchive app_name: " + value(archiveAppName)
                    + "\nResource detail: " + value(resourceDetail);
        }

        private static String value(String s) { return s == null ? "(none)" : s; }
    }
}
