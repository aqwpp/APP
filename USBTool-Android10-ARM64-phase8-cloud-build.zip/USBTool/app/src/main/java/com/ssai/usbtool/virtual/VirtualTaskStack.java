package com.ssai.usbtool.virtual;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * In-memory logical task stack, scoped by profile ID.
 *
 * This is a scheduling data structure for USBTool's proxy layer. It does not
 * register tasks with Android ActivityTaskManager and does not run foreign
 * Activity classes. Persistence and cross-process synchronization are future
 * work; callers must not assume this survives process death.
 */
public final class VirtualTaskStack {
    private final Map<String, List<VirtualActivityRecord>> tasks = new HashMap<>();

    public synchronized void push(VirtualActivityRecord record) {
        if (record == null) throw new IllegalArgumentException("record 不能为空");
        List<VirtualActivityRecord> stack = tasks.get(record.getTaskId());
        if (stack == null) {
            stack = new ArrayList<>();
            tasks.put(record.getTaskId(), stack);
        }
        stack.add(record);
    }

    public synchronized VirtualActivityRecord peek(String taskId) {
        List<VirtualActivityRecord> stack = tasks.get(taskId);
        return stack == null || stack.isEmpty() ? null : stack.get(stack.size() - 1);
    }

    public synchronized VirtualActivityRecord pop(String taskId) {
        List<VirtualActivityRecord> stack = tasks.get(taskId);
        if (stack == null || stack.isEmpty()) return null;
        VirtualActivityRecord removed = stack.remove(stack.size() - 1);
        removed.setState(ActivityLifecycleState.DESTROYED);
        if (stack.isEmpty()) tasks.remove(taskId);
        return removed;
    }

    public synchronized List<VirtualActivityRecord> snapshot(String taskId) {
        List<VirtualActivityRecord> stack = tasks.get(taskId);
        if (stack == null) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<>(stack));
    }

    public synchronized void clearProfile(String profileId) {
        List<String> emptyTasks = new ArrayList<>();
        for (Map.Entry<String, List<VirtualActivityRecord>> entry : tasks.entrySet()) {
            List<VirtualActivityRecord> stack = entry.getValue();
            for (int i = stack.size() - 1; i >= 0; i--) {
                VirtualActivityRecord record = stack.get(i);
                if (profileId.equals(record.getProfileId())) {
                    record.setState(ActivityLifecycleState.DESTROYED);
                    stack.remove(i);
                }
            }
            if (stack.isEmpty()) emptyTasks.add(entry.getKey());
        }
        for (String taskId : emptyTasks) tasks.remove(taskId);
    }

    public synchronized int taskCount() { return tasks.size(); }
}
