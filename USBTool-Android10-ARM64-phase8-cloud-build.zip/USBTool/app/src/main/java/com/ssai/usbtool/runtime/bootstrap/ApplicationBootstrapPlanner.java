package com.ssai.usbtool.runtime.bootstrap;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** Pure-Java policy analysis for the next Application/component bootstrap phase. */
public final class ApplicationBootstrapPlanner {
    private ApplicationBootstrapPlanner() {}

    public static ApplicationBootstrapPlan analyze(ImportedApkDescriptor apk) {
        ArrayList<String> blockers = new ArrayList<>();
        ArrayList<String> warnings = new ArrayList<>();
        if (apk == null || empty(apk.packageName) || empty(apk.apkPath)) {
            blockers.add("APK 描述缺少包名或文件路径，无法建立启动计划。");
            return new ApplicationBootstrapPlan(
                    ApplicationBootstrapPlan.Status.INVALID_APK_METADATA,
                    apk == null ? null : apk.packageName,
                    apk == null ? null : apk.applicationClass,
                    blockers, warnings, true);
        }

        if (!apk.hasCode) blockers.add("APK 未声明可执行代码（android:hasCode=false）。");
        if (!empty(apk.sharedUserId)) {
            blockers.add("声明了 sharedUserId；普通宿主进程不能安全模拟其安装身份或 UID 语义。");
        }

        boolean customApplication = !empty(apk.applicationClass)
                && !"android.app.Application".equals(apk.applicationClass);
        if (customApplication) {
            blockers.add("声明了自定义 Application。公开 SDK 没有受支持的 API，可在宿主进程中完整复现系统的 LoadedApk/ActivityThread 初始化流程。");
        } else {
            warnings.add("未声明自定义 Application；这并不意味着可直接创建 APK 的真实 Application/Context。");
        }

        if (!apk.activities.isEmpty()) {
            blockers.add("包含 " + apk.activities.size() + " 个 Activity；必须由系统组件管理器创建并维护其生命周期、窗口、任务栈和主题资源。");
            ActivityLaunchCompatibilityAnalyzer.Analysis activityAnalysis =
                    ActivityLaunchCompatibilityAnalyzer.analyze(apk);
            blockers.addAll(activityAnalysis.blockers);
            warnings.addAll(activityAnalysis.warnings);
        }
        if (!apk.services.isEmpty()) {
            blockers.add("包含 " + apk.services.size() + " 个 Service；需要系统服务调度、前台服务和绑定生命周期代理。");
        }
        if (!apk.receivers.isEmpty()) {
            blockers.add("包含 " + apk.receivers.size() + " 个 Receiver；需要广播解析、权限和进程启动语义。");
        }
        if (!apk.providers.isEmpty()) {
            blockers.add("包含 " + apk.providers.size() + " 个 Provider；需要在 Application 初始化前处理 provider 安装、authority 路由及 Binder 调用。");
        }

        Set<String> processes = new HashSet<>();
        if (!empty(apk.defaultProcessName)) processes.add(apk.defaultProcessName);
        inspectProcesses(apk.activities, processes, blockers);
        inspectProcesses(apk.services, processes, blockers);
        inspectProcesses(apk.receivers, processes, blockers);
        inspectProcesses(apk.providers, processes, blockers);
        if (processes.size() > 1) {
            blockers.add("Manifest 声明多个进程（" + processes.size() + " 个）；单个 :runtime 进程不能等价模拟原应用的多进程模型。");
        }

        if (!apk.nativeAbis.isEmpty() && !apk.nativeAbis.contains("arm64-v8a")) {
            blockers.add("APK 含 Native 库，但未发现 arm64-v8a 版本；当前 USBTool 目标 ABI 无法保证加载兼容。");
        } else if (apk.nativeAbis.contains("arm64-v8a")) {
            warnings.add("检测到 arm64-v8a Native 库；仍需处理 linker namespace、库依赖和原应用 nativeLibraryDir 语义。");
        }
        if (!apk.requestedPermissions.isEmpty()) {
            warnings.add("APK 请求 " + apk.requestedPermissions.size() + " 项权限；宿主 UID 的授权状态不能代表原 APK 的独立权限状态，不能直接授予或伪造。");
        }
        if (apk.minSdkVersion > 29) {
            blockers.add("APK minSdkVersion=" + apk.minSdkVersion + " 高于 USBTool 目标 Android 10/API 29。");
        }
        if (apk.targetSdkVersion > 29) {
            warnings.add("APK targetSdkVersion=" + apk.targetSdkVersion + " 高于 API 29；行为兼容性需要单独验证。");
        }
        if (apk.debuggable) warnings.add("APK 标记为 debuggable；这不代表它可信，仍应只对自编译测试 APK 使用代码加载实验。");

        // Deliberately conservative: an ordinary APK's Application is created by
        // ActivityThread/LoadedApk and its component graph is system-managed.
        return new ApplicationBootstrapPlan(
                ApplicationBootstrapPlan.Status.METADATA_ANALYSIS_COMPLETE,
                apk.packageName, apk.applicationClass, blockers, warnings, true);
    }

    private static void inspectProcesses(java.util.List<ImportedApkDescriptor.Component> components,
                                         Set<String> processes, java.util.List<String> blockers) {
        for (ImportedApkDescriptor.Component component : components) {
            if (!empty(component.processName)) processes.add(component.processName);
            if (component.isolatedProcess) {
                blockers.add("组件 " + component.className + " 声明 isolatedProcess；普通宿主不能重建系统隔离 UID。");
            }
        }
    }

    private static boolean empty(String value) { return value == null || value.trim().isEmpty(); }
}
