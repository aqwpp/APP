package com.ssai.usbtool.runtime.bootstrap;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;

import java.io.File;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Reads imported APK manifest metadata only. Never loads or initializes APK classes. */
public final class ImportedApkDescriptorReader {
    private ImportedApkDescriptorReader() {}

    public static ImportedApkDescriptor read(Context context, File apkFile) throws Exception {
        if (apkFile == null || !apkFile.isFile() || !apkFile.canRead()) {
            throw new IllegalArgumentException("APK 文件不存在或不可读");
        }
        PackageManager pm = context.getPackageManager();
        int flags = PackageManager.GET_ACTIVITIES | PackageManager.GET_SERVICES
                | PackageManager.GET_RECEIVERS | PackageManager.GET_PROVIDERS
                | PackageManager.GET_PERMISSIONS | PackageManager.GET_META_DATA;
        PackageInfo info = pm.getPackageArchiveInfo(apkFile.getAbsolutePath(), flags);
        if (info == null || info.applicationInfo == null) {
            throw new IllegalArgumentException("PackageManager 无法解析 APK Manifest");
        }

        ApplicationInfo app = info.applicationInfo;
        app.sourceDir = apkFile.getAbsolutePath();
        app.publicSourceDir = apkFile.getAbsolutePath();

        ImportedApkDescriptor out = new ImportedApkDescriptor();
        out.packageName = info.packageName;
        out.label = String.valueOf(pm.getApplicationLabel(app));
        out.versionName = info.versionName;
        out.versionCode = info.getLongVersionCode();
        out.apkPath = apkFile.getAbsolutePath();
        out.applicationClass = normalizeClassName(info.packageName, app.className);
        out.defaultProcessName = app.processName == null ? info.packageName : app.processName;
        out.minSdkVersion = app.minSdkVersion;
        out.targetSdkVersion = app.targetSdkVersion;
        out.hasCode = (app.flags & ApplicationInfo.FLAG_HAS_CODE) != 0;
        out.debuggable = (app.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        out.sharedUserId = info.sharedUserId;

        if (info.requestedPermissions != null) {
            for (String permission : info.requestedPermissions) {
                if (permission != null) out.requestedPermissions.add(permission);
            }
        }
        readNativeAbis(apkFile, out);

        if (info.activities != null) for (ActivityInfo c : info.activities) {
            out.activities.add(new ImportedApkDescriptor.Component(c.name,
                    process(c.processName, info.packageName), c.enabled, c.exported,
                    false, null, activityLaunchMetadata(c)));
        }
        if (info.services != null) for (ServiceInfo c : info.services) {
            out.services.add(new ImportedApkDescriptor.Component(c.name,
                    process(c.processName, info.packageName), c.enabled, c.exported,
                    c.isolatedProcess, null));
        }
        if (info.receivers != null) for (ActivityInfo c : info.receivers) {
            out.receivers.add(new ImportedApkDescriptor.Component(c.name,
                    process(c.processName, info.packageName), c.enabled, c.exported,
                    false, null));
        }
        if (info.providers != null) for (ProviderInfo c : info.providers) {
            out.providers.add(new ImportedApkDescriptor.Component(c.name,
                    process(c.processName, info.packageName), c.enabled, c.exported,
                    false, c.authority));
        }
        return out;
    }

    private static void readNativeAbis(File apk, ImportedApkDescriptor out) {
        try (ZipFile zip = new ZipFile(apk)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                String name = entries.nextElement().getName();
                if (!name.startsWith("lib/")) continue;
                String[] parts = name.split("/");
                if (parts.length >= 3 && parts[2].endsWith(".so")
                        && !out.nativeAbis.contains(parts[1])) {
                    out.nativeAbis.add(parts[1]);
                }
            }
        } catch (Exception ignored) {
            // A failed native ABI scan is reported as no detected ABI; the APK metadata read remains usable.
        }
    }


    private static ImportedApkDescriptor.ActivityLaunchMetadata activityLaunchMetadata(ActivityInfo info) {
        String launchMode;
        switch (info.launchMode) {
            case ActivityInfo.LAUNCH_SINGLE_TOP: launchMode = "singleTop"; break;
            case ActivityInfo.LAUNCH_SINGLE_TASK: launchMode = "singleTask"; break;
            case ActivityInfo.LAUNCH_SINGLE_INSTANCE: launchMode = "singleInstance"; break;
            case ActivityInfo.LAUNCH_SINGLE_INSTANCE_PER_TASK: launchMode = "singleInstancePerTask"; break;
            default: launchMode = "standard"; break;
        }

        String documentMode;
        switch (info.documentLaunchMode) {
            case ActivityInfo.DOCUMENT_LAUNCH_INTO_EXISTING: documentMode = "intoExisting"; break;
            case ActivityInfo.DOCUMENT_LAUNCH_ALWAYS: documentMode = "always"; break;
            case ActivityInfo.DOCUMENT_LAUNCH_NEVER: documentMode = "never"; break;
            default: documentMode = "none"; break;
        }

        return new ImportedApkDescriptor.ActivityLaunchMetadata(
                launchMode, documentMode, info.taskAffinity, info.permission,
                info.targetActivity, info.parentActivityName,
                info.theme, info.configChanges, info.screenOrientation,
                info.directBootAware,
                (info.flags & ActivityInfo.FLAG_NO_HISTORY) != 0,
                (info.flags & ActivityInfo.FLAG_FINISH_ON_TASK_LAUNCH) != 0,
                (info.flags & ActivityInfo.FLAG_ALLOW_TASK_REPARENTING) != 0,
                (info.flags & ActivityInfo.FLAG_EXCLUDE_FROM_RECENTS) != 0);
    }

    private static String process(String value, String packageName) {
        return value == null ? packageName : value;
    }

    private static String normalizeClassName(String packageName, String name) {
        if (name == null || name.length() == 0) return "android.app.Application";
        if (name.startsWith(".")) return packageName + name;
        if (name.indexOf('.') < 0) return packageName + "." + name;
        return name;
    }
}
