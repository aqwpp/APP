package com.ssai.usbtool;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

final class ProfileStore {
    private final File db;
    private final File usersDir;

    static final class Profile {
        String id, dataDir;
    }
    static final class AppRecord {
        String id, packageName, label, version, apkPath;
        List<Profile> profiles = new ArrayList<>();
    }

    ProfileStore(Context c) {
        db = new File(c.getFilesDir(), "apps.json");
        usersDir = new File(c.getFilesDir(), "virtual-users");
        if (!usersDir.exists()) usersDir.mkdirs();
    }

    synchronized List<AppRecord> getAll() {
        List<AppRecord> out = new ArrayList<>();
        try {
            if (!db.exists()) return out;
            JSONArray arr = new JSONArray(new String(Files.readAllBytes(db.toPath()), StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) out.add(fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) { }
        return out;
    }

    synchronized void add(String pkg, String label, String version, String apkPath) throws Exception {
        for (AppRecord a : getAll()) {
            if (a.packageName.equals(pkg)) throw new Exception("该包名已导入：" + pkg);
        }
        AppRecord a = new AppRecord();
        a.id = UUID.randomUUID().toString();
        a.packageName = pkg; a.label = label; a.version = version; a.apkPath = apkPath;
        createProfile(a);
        List<AppRecord> all = getAll(); all.add(a); save(all);
    }

    synchronized void createProfile(String appId) {
        List<AppRecord> all = getAll();
        for (AppRecord a : all) if (a.id.equals(appId)) {
            createProfile(a);
            save(all);
            return;
        }
    }

    private void createProfile(AppRecord a) {
        try {
            Profile p = new Profile();
            p.id = UUID.randomUUID().toString();
            File dir = new File(new File(usersDir, safe(a.id)), safe(p.id));
            if (!dir.mkdirs() && !dir.isDirectory()) return;
            p.dataDir = dir.getAbsolutePath();
            a.profiles.add(p);
        } catch (Exception ignored) { }
    }

    synchronized void removeApp(String id) {
        List<AppRecord> all = getAll();
        List<AppRecord> keep = new ArrayList<>();
        for (AppRecord a : all) {
            if (a.id.equals(id)) {
                deleteTree(new File(usersDir, safe(a.id)));
                new File(a.apkPath).delete();
            } else keep.add(a);
        }
        save(keep);
    }

    private void save(List<AppRecord> all) {
        try {
            JSONArray arr = new JSONArray();
            for (AppRecord a : all) {
                JSONObject o = new JSONObject();
                o.put("id", a.id); o.put("packageName", a.packageName);
                o.put("label", a.label); o.put("version", a.version); o.put("apkPath", a.apkPath);
                JSONArray ps = new JSONArray();
                for (Profile p : a.profiles) {
                    JSONObject po = new JSONObject(); po.put("id", p.id); po.put("dataDir", p.dataDir); ps.put(po);
                }
                o.put("profiles", ps); arr.put(o);
            }
            Files.write(db.toPath(), arr.toString(2).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private AppRecord fromJson(JSONObject o) throws Exception {
        AppRecord a = new AppRecord();
        a.id=o.getString("id"); a.packageName=o.getString("packageName");
        a.label=o.getString("label"); a.version=o.getString("version"); a.apkPath=o.getString("apkPath");
        JSONArray ps=o.optJSONArray("profiles");
        if (ps != null) for(int i=0;i<ps.length();i++){
            JSONObject po=ps.getJSONObject(i); Profile p=new Profile();
            p.id=po.getString("id"); p.dataDir=po.getString("dataDir"); a.profiles.add(p);
        }
        return a;
    }
    private static String safe(String s) { return s.replaceAll("[^a-zA-Z0-9_-]", "_"); }
    private static void deleteTree(File f) {
        if (f.isDirectory()) { File[] children=f.listFiles(); if(children!=null) for(File c:children) deleteTree(c); }
        f.delete();
    }
}
