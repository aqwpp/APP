package com.ssai.usbtool.virtual;

import java.util.UUID;

/**
 * Describes a logical Activity entry in USBTool's virtual task model.
 *
 * It is metadata only: Android has not instantiated the imported APK's
 * Activity class. The actual Android Activity in this prototype is ProxyActivity.
 */
public final class VirtualActivityRecord {
    private final String instanceId;
    private final String taskId;
    private final String profileId;
    private final String packageId;
    private final String packageName;
    private final String className;
    private ActivityLifecycleState state;

    public VirtualActivityRecord(String taskId, String profileId,
                                 String packageId, String packageName,
                                 String className) {
        this.instanceId = UUID.randomUUID().toString();
        this.taskId = require(taskId, "taskId");
        this.profileId = require(profileId, "profileId");
        this.packageId = require(packageId, "packageId");
        this.packageName = require(packageName, "packageName");
        this.className = require(className, "className");
        this.state = ActivityLifecycleState.INITIALIZED;
    }

    private static String require(String value, String name) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " 不能为空");
        }
        return value;
    }

    public String getInstanceId() { return instanceId; }
    public String getTaskId() { return taskId; }
    public String getProfileId() { return profileId; }
    public String getPackageId() { return packageId; }
    public String getPackageName() { return packageName; }
    public String getClassName() { return className; }
    public ActivityLifecycleState getState() { return state; }

    void setState(ActivityLifecycleState next) { state = next; }
}
