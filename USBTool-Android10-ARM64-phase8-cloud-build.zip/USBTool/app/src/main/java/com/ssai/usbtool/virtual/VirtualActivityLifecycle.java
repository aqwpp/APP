package com.ssai.usbtool.virtual;

/**
 * Validates lifecycle transitions observed by the host proxy Activity.
 * This models host-side routing state, not callbacks delivered to the imported
 * application's Activity object.
 */
public final class VirtualActivityLifecycle {
    private VirtualActivityLifecycle() {}

    public static void moveTo(VirtualActivityRecord record, ActivityLifecycleState next) {
        if (record == null || next == null) throw new IllegalArgumentException("参数不能为空");
        ActivityLifecycleState current = record.getState();
        if (!isAllowed(current, next)) {
            throw new IllegalStateException("非法生命周期转换：" + current + " -> " + next);
        }
        record.setState(next);
    }

    private static boolean isAllowed(ActivityLifecycleState from, ActivityLifecycleState to) {
        switch (from) {
            case INITIALIZED:
                return to == ActivityLifecycleState.CREATED || to == ActivityLifecycleState.DESTROYED;
            case CREATED:
                return to == ActivityLifecycleState.STARTED || to == ActivityLifecycleState.DESTROYED;
            case STARTED:
                return to == ActivityLifecycleState.RESUMED || to == ActivityLifecycleState.STOPPED
                        || to == ActivityLifecycleState.DESTROYED;
            case RESUMED:
                return to == ActivityLifecycleState.PAUSED;
            case PAUSED:
                return to == ActivityLifecycleState.RESUMED || to == ActivityLifecycleState.STOPPED
                        || to == ActivityLifecycleState.DESTROYED;
            case STOPPED:
                return to == ActivityLifecycleState.STARTED || to == ActivityLifecycleState.DESTROYED;
            case DESTROYED:
            default:
                return false;
        }
    }
}
