package com.ssai.usbtool.runtime.ipc;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;

import java.util.UUID;

/**
 * Private Binder/Messenger endpoint hosted in the dedicated :runtime process.
 *
 * The process is separate from the UI process, but Android assigns both
 * processes the same application UID. This is a reliability/architecture
 * boundary, NOT a security sandbox against imported APK code.
 */
public final class RuntimeSessionService extends Service {
    private final RuntimeSessionRegistry sessions = new RuntimeSessionRegistry();
    private final Messenger endpoint =
            new Messenger(new IncomingHandler(Looper.getMainLooper()));

    @Override public IBinder onBind(Intent intent) {
        return endpoint.getBinder();
    }

    private final class IncomingHandler extends Handler {
        IncomingHandler(Looper looper) { super(looper); }

        @Override public void handleMessage(Message message) {
            if (message.replyTo == null) return;
            Bundle data = message.getData();
            Bundle result = new Bundle();
            int responseCode = RuntimeIpcProtocol.MSG_REPLY;

            try {
                switch (message.what) {
                    case RuntimeIpcProtocol.MSG_PING:
                        result.putString(RuntimeIpcProtocol.KEY_STATUS, "RUNTIME_PROCESS_READY");
                        break;

                    case RuntimeIpcProtocol.MSG_OPEN_SESSION: {
                        String profileId = data.getString(RuntimeIpcProtocol.KEY_PROFILE_ID);
                        String packageName = data.getString(RuntimeIpcProtocol.KEY_PACKAGE_NAME);
                        RuntimeSessionRegistry.Session session = sessions.open(profileId, packageName);
                        result.putString(RuntimeIpcProtocol.KEY_STATUS, "SESSION_RECORD_CREATED");
                        result.putString(RuntimeIpcProtocol.KEY_SESSION_ID, session.id);
                        break;
                    }

                    case RuntimeIpcProtocol.MSG_CLOSE_SESSION: {
                        String id = data.getString(RuntimeIpcProtocol.KEY_SESSION_ID);
                        boolean removed = sessions.close(id);
                        result.putString(RuntimeIpcProtocol.KEY_STATUS,
                                removed ? "SESSION_RECORD_CLOSED" : "SESSION_NOT_FOUND");
                        break;
                    }

                    default:
                        result.putString(RuntimeIpcProtocol.KEY_ERROR, "UNKNOWN_MESSAGE");
                        break;
                }
            } catch (IllegalArgumentException e) {
                result.putString(RuntimeIpcProtocol.KEY_ERROR, e.getMessage());
            }

            result.putInt(RuntimeIpcProtocol.KEY_PID, Process.myPid());
            result.putString(RuntimeIpcProtocol.KEY_PROCESS_NAME,
                    getPackageName() + ":runtime");
            result.putInt("active_session_records", sessions.size());

            Message reply = Message.obtain(null, responseCode);
            reply.setData(result);
            try {
                message.replyTo.send(reply);
            } catch (RemoteException ignored) {
                // Client disconnected; no app code is loaded and no state is persisted.
            }
        }
    }
}
