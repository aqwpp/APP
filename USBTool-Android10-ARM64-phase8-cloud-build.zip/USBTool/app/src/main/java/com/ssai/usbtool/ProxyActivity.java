package com.ssai.usbtool;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ssai.usbtool.virtual.ActivityLifecycleState;
import com.ssai.usbtool.virtual.VirtualActivityLifecycle;
import com.ssai.usbtool.virtual.VirtualActivityRecord;
import com.ssai.usbtool.virtual.VirtualLaunchRouter;

/**
 * Host proxy Activity. Android instantiates this class, not the imported APK's
 * Activity class. The record below tracks the proxy's logical target metadata.
 */
public class ProxyActivity extends Activity {
    private VirtualActivityRecord record;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String pkgId = getIntent().getStringExtra(VirtualLaunchRouter.EXTRA_PACKAGE_ID);
        String pkg = getIntent().getStringExtra(VirtualLaunchRouter.EXTRA_PACKAGE_NAME);
        String activity = getIntent().getStringExtra(VirtualLaunchRouter.EXTRA_ACTIVITY_NAME);
        String profile = getIntent().getStringExtra(VirtualLaunchRouter.EXTRA_PROFILE_ID);
        String task = getIntent().getStringExtra(VirtualLaunchRouter.EXTRA_TASK_ID);

        try {
            record = new VirtualActivityRecord(task, profile, pkgId, pkg, activity);
            VirtualActivityLifecycle.moveTo(record, ActivityLifecycleState.CREATED);
        } catch (Exception e) {
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("USBTool Activity 调度原型");
        title.setTextSize(22);
        root.addView(title);

        status = new TextView(this);
        status.setPadding(0, 20, 0, 0);
        root.addView(status);
        setContentView(root);
        updateStatus();
    }

    @Override protected void onStart() {
        super.onStart();
        transition(ActivityLifecycleState.STARTED);
    }

    @Override protected void onResume() {
        super.onResume();
        transition(ActivityLifecycleState.RESUMED);
    }

    @Override protected void onPause() {
        transition(ActivityLifecycleState.PAUSED);
        super.onPause();
    }

    @Override protected void onStop() {
        transition(ActivityLifecycleState.STOPPED);
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (record != null && record.getState() != ActivityLifecycleState.DESTROYED) {
            if (record.getState() == ActivityLifecycleState.RESUMED) {
                transition(ActivityLifecycleState.PAUSED);
            }
            transition(ActivityLifecycleState.DESTROYED);
        }
        super.onDestroy();
    }

    private void transition(ActivityLifecycleState next) {
        if (record == null) return;
        try {
            VirtualActivityLifecycle.moveTo(record, next);
            updateStatus();
        } catch (IllegalStateException ignored) {
            // Android may deliver lifecycle callbacks in edge-case sequences;
            // keep the proxy alive and expose only validated state transitions.
        }
    }

    private void updateStatus() {
        if (status == null || record == null) return;
        status.setText("目标包名：" + record.getPackageName()
                + "\n目标 Activity：" + record.getClassName()
                + "\n虚拟实例：" + record.getProfileId()
                + "\n任务：" + record.getTaskId()
                + "\n代理生命周期：" + record.getState()
                + "\n\n注意：当前实际运行的是 USBTool 的 ProxyActivity。"
                + "\n目标 APK Activity 尚未被 Android 实例化。");
    }
}
