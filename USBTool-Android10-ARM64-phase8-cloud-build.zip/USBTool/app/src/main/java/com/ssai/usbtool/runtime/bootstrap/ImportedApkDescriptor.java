package com.ssai.usbtool.runtime.bootstrap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable-ish manifest summary. It contains metadata only; no APK code is loaded. */
public final class ImportedApkDescriptor {
    public String packageName;
    public String label;
    public String versionName;
    public long versionCode;
    public String apkPath;
    public String applicationClass;
    public String defaultProcessName;
    public int minSdkVersion;
    public int targetSdkVersion;
    public boolean hasCode;
    public boolean debuggable;
    public String sharedUserId;
    public final List<String> requestedPermissions = new ArrayList<>();
    public final List<String> nativeAbis = new ArrayList<>();
    public final List<Component> activities = new ArrayList<>();
    public final List<Component> services = new ArrayList<>();
    public final List<Component> receivers = new ArrayList<>();
    public final List<Component> providers = new ArrayList<>();

    public int componentCount() {
        return activities.size() + services.size() + receivers.size() + providers.size();
    }

    public static final class Component {
        public final String className;
        public final String processName;
        public final boolean enabled;
        public final boolean exported;
        public final boolean isolatedProcess;
        public final String authorities;
        /** Present only for Activity components; values are copied from public ActivityInfo fields. */
        public final ActivityLaunchMetadata activityLaunch;

        public Component(String className, String processName, boolean enabled,
                         boolean exported, boolean isolatedProcess, String authorities) {
            this(className, processName, enabled, exported, isolatedProcess, authorities, null);
        }

        public Component(String className, String processName, boolean enabled,
                         boolean exported, boolean isolatedProcess, String authorities,
                         ActivityLaunchMetadata activityLaunch) {
            this.className = className;
            this.processName = processName;
            this.enabled = enabled;
            this.exported = exported;
            this.isolatedProcess = isolatedProcess;
            this.authorities = authorities;
            this.activityLaunch = activityLaunch;
        }
    }

    /** Pure-data snapshot of Android ActivityInfo launch/task attributes. */
    public static final class ActivityLaunchMetadata {
        public final String launchMode;
        public final String documentLaunchMode;
        public final String taskAffinity;
        public final String permission;
        public final String targetActivity;
        public final String parentActivityName;
        public final int themeResourceId;
        public final int configChanges;
        public final int screenOrientation;
        public final boolean directBootAware;
        public final boolean noHistory;
        public final boolean finishOnTaskLaunch;
        public final boolean allowTaskReparenting;
        public final boolean excludeFromRecents;

        public ActivityLaunchMetadata(String launchMode, String documentLaunchMode,
                                      String taskAffinity, String permission,
                                      String targetActivity, String parentActivityName,
                                      int themeResourceId, int configChanges,
                                      int screenOrientation, boolean directBootAware,
                                      boolean noHistory, boolean finishOnTaskLaunch,
                                      boolean allowTaskReparenting, boolean excludeFromRecents) {
            this.launchMode = launchMode;
            this.documentLaunchMode = documentLaunchMode;
            this.taskAffinity = taskAffinity;
            this.permission = permission;
            this.targetActivity = targetActivity;
            this.parentActivityName = parentActivityName;
            this.themeResourceId = themeResourceId;
            this.configChanges = configChanges;
            this.screenOrientation = screenOrientation;
            this.directBootAware = directBootAware;
            this.noHistory = noHistory;
            this.finishOnTaskLaunch = finishOnTaskLaunch;
            this.allowTaskReparenting = allowTaskReparenting;
            this.excludeFromRecents = excludeFromRecents;
        }
    }
}
