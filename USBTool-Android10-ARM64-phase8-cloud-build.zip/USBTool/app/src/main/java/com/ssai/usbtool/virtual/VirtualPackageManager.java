package com.ssai.usbtool.virtual;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Phase 3 metadata registry for APKs imported into USBTool.
 *
 * This intentionally does not claim that an imported package is installed
 * into Android's PackageManager. It records metadata and component names
 * for the future runtime layer.
 */
public final class VirtualPackageManager {
    private final Context context;
    private final File registry;

    public VirtualPackageManager(Context context) {
        this.context = context.getApplicationContext();
        this.registry = new File(context.getFilesDir(), "virtual-packages.json");
    }

    public InstalledPackage inspectAndRegister(File apkFile) throws Exception {
        if (apkFile == null || !apkFile.isFile()) {
            throw new IllegalArgumentException("APK 文件不存在");
        }

        PackageManager pm = context.getPackageManager();
        PackageInfo info = pm.getPackageArchiveInfo(
                apkFile.getAbsolutePath(),
                PackageManager.GET_ACTIVITIES | PackageManager.GET_SERVICES |
                PackageManager.GET_RECEIVERS | PackageManager.GET_PROVIDERS |
                PackageManager.GET_META_DATA);

        if (info == null || info.applicationInfo == null) {
            throw new IllegalArgumentException("无法解析 APK");
        }

        ApplicationInfo appInfo = info.applicationInfo;
        appInfo.sourceDir = apkFile.getAbsolutePath();
        appInfo.publicSourceDir = apkFile.getAbsolutePath();

        InstalledPackage record = new InstalledPackage();
        record.id = UUID.randomUUID().toString();
        record.packageName = info.packageName;
        record.versionName = info.versionName == null ? "" : info.versionName;
        record.versionCode = info.getLongVersionCode();
        record.apkPath = apkFile.getAbsolutePath();

        CharSequence label = pm.getApplicationLabel(appInfo);
        record.label = label == null ? info.packageName : label.toString();

        if (info.activities != null) {
            for (ActivityInfo activity : info.activities) {
                ComponentRecord c = new ComponentRecord();
                c.className = activity.name;
                c.exported = activity.exported;
                c.enabled = activity.enabled;
                record.activities.add(c);
            }
        }
        save(record);
        return record;
    }

    public List<InstalledPackage> getInstalledPackages() {
        List<InstalledPackage> result = new ArrayList<>();
        if (!registry.exists()) return result;
        try {
            JSONArray array = new JSONArray(new String(
                    Files.readAllBytes(registry.toPath()), StandardCharsets.UTF_8));
            for (int i = 0; i < array.length(); i++) {
                result.add(fromJson(array.getJSONObject(i)));
            }
        } catch (Exception ignored) { }
        return result;
    }

    private synchronized void save(InstalledPackage item) throws Exception {
        JSONArray array = new JSONArray();
        for (InstalledPackage old : getInstalledPackages()) {
            if (!old.packageName.equals(item.packageName)) array.put(toJson(old));
        }
        array.put(toJson(item));
        Files.write(registry.toPath(), array.toString(2).getBytes(StandardCharsets.UTF_8));
    }

    private JSONObject toJson(InstalledPackage p) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", p.id);
        o.put("packageName", p.packageName);
        o.put("label", p.label);
        o.put("versionName", p.versionName);
        o.put("versionCode", p.versionCode);
        o.put("apkPath", p.apkPath);
        JSONArray activities = new JSONArray();
        for (ComponentRecord c : p.activities) {
            JSONObject a = new JSONObject();
            a.put("className", c.className);
            a.put("exported", c.exported);
            a.put("enabled", c.enabled);
            activities.put(a);
        }
        o.put("activities", activities);
        return o;
    }

    private InstalledPackage fromJson(JSONObject o) throws Exception {
        InstalledPackage p = new InstalledPackage();
        p.id = o.getString("id");
        p.packageName = o.getString("packageName");
        p.label = o.optString("label", p.packageName);
        p.versionName = o.optString("versionName", "");
        p.versionCode = o.optLong("versionCode");
        p.apkPath = o.getString("apkPath");
        JSONArray activities = o.optJSONArray("activities");
        if (activities != null) {
            for (int i = 0; i < activities.length(); i++) {
                JSONObject a = activities.getJSONObject(i);
                ComponentRecord c = new ComponentRecord();
                c.className = a.getString("className");
                c.exported = a.optBoolean("exported");
                c.enabled = a.optBoolean("enabled", true);
                p.activities.add(c);
            }
        }
        return p;
    }

    public static final class InstalledPackage {
        public String id, packageName, label, versionName, apkPath;
        public long versionCode;
        public final List<ComponentRecord> activities = new ArrayList<>();
    }

    public static final class ComponentRecord {
        public String className;
        public boolean exported, enabled;
    }
}
