package com.ssai.usbtool.runtime.bootstrap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A conservative feasibility report, not an executable Application bootstrap. */
public final class ApplicationBootstrapPlan {
    public enum Status {
        METADATA_ANALYSIS_COMPLETE,
        INVALID_APK_METADATA
    }

    public final Status status;
    public final String packageName;
    public final String applicationClass;
    public final List<String> blockers;
    public final List<String> warnings;
    public final boolean requiresAndroidFrameworkPackageRuntime;

    ApplicationBootstrapPlan(Status status, String packageName, String applicationClass,
                             List<String> blockers, List<String> warnings,
                             boolean requiresAndroidFrameworkPackageRuntime) {
        this.status = status;
        this.packageName = packageName;
        this.applicationClass = applicationClass;
        this.blockers = Collections.unmodifiableList(new ArrayList<>(blockers));
        this.warnings = Collections.unmodifiableList(new ArrayList<>(warnings));
        this.requiresAndroidFrameworkPackageRuntime = requiresAndroidFrameworkPackageRuntime;
    }

    public String toReport() {
        StringBuilder out = new StringBuilder();
        out.append("分析状态：").append(status).append('\n');
        out.append("包名：").append(value(packageName)).append('\n');
        out.append("Application：").append(value(applicationClass)).append('\n');
        out.append("需要 Android framework 级包运行时：")
                .append(requiresAndroidFrameworkPackageRuntime ? "是" : "否").append('\n');
        out.append("阻塞项（").append(blockers.size()).append("）：\n");
        for (String item : blockers) out.append("• ").append(item).append('\n');
        out.append("注意事项（").append(warnings.size()).append("）：\n");
        for (String item : warnings) out.append("• ").append(item).append('\n');
        out.append("\n本报告只分析 APK Manifest/包元数据；没有实例化 Application，未运行 APK 代码。");
        return out.toString();
    }

    private static String value(String text) { return text == null ? "(未声明)" : text; }
}
