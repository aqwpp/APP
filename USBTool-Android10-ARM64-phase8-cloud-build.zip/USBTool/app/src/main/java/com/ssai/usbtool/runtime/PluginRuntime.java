package com.ssai.usbtool.runtime;

import android.content.Context;
import android.view.View;

import dalvik.system.DexClassLoader;
import java.io.File;

/**
 * Limited in-process DexClassLoader prototype for trusted test plugins.
 *
 * Security: code loaded here runs with the host app's UID and permissions.
 * Never load APKs from untrusted sources. This does not virtualize package
 * identity, Android components, resources, providers, services or permissions.
 */
public final class PluginRuntime {
    private PluginRuntime() {}

    public static View loadTrustedPlugin(Context context, String apkPath,
                                         String implementationClass) throws Exception {
        File apk = new File(apkPath);
        if (!apk.isFile() || !apk.canRead()) {
            throw new IllegalArgumentException("APK 不存在或不可读");
        }
        if (implementationClass == null || implementationClass.trim().isEmpty()) {
            throw new IllegalArgumentException("插件入口类名不能为空");
        }

        File optimized = new File(context.getCodeCacheDir(), "plugin-dex");
        if (!optimized.exists() && !optimized.mkdirs()) {
            throw new IllegalStateException("无法创建 dex 优化目录");
        }
        File nativeLibs = new File(context.getFilesDir(), "plugin-native-libs");
        if (!nativeLibs.exists()) nativeLibs.mkdirs();

        DexClassLoader loader = new DexClassLoader(
                apk.getAbsolutePath(),
                optimized.getAbsolutePath(),
                nativeLibs.getAbsolutePath(),
                context.getClassLoader());

        Class<?> type = loader.loadClass(implementationClass);
        if (!PluginEntry.class.isAssignableFrom(type)) {
            throw new IllegalArgumentException("插件入口必须实现 PluginEntry");
        }
        Object instance = type.getDeclaredConstructor().newInstance();
        return ((PluginEntry) instance).createView(context);
    }
}
