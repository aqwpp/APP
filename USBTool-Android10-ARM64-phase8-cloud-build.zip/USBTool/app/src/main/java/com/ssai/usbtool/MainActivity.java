package com.ssai.usbtool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

import com.ssai.usbtool.runtime.ipc.RuntimeProcessClient;
import com.ssai.usbtool.runtime.bootstrap.ImportedApkDescriptor;
import com.ssai.usbtool.runtime.bootstrap.ImportedApkDescriptorReader;
import com.ssai.usbtool.runtime.bootstrap.ApplicationBootstrapPlan;
import com.ssai.usbtool.runtime.bootstrap.ApplicationBootstrapPlanner;

public class MainActivity extends Activity {
    private static final int REQUEST_APK = 1001;
    private LinearLayout list;
    private ProfileStore store;
    private RuntimeProcessClient runtimeProcessClient;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new ProfileStore(this);
        buildUi();
        refresh();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(32, 36, 32, 24);

        TextView title = new TextView(this);
        title.setText("USBTool");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Android 10 · ARM64 · 虚拟应用管理原型");
        subtitle.setTextSize(13);
        page.addView(subtitle);

        Button add = new Button(this);
        add.setText("导入 APK");
        add.setOnClickListener(v -> chooseApk());
        page.addView(add);

        Button ipcTest = new Button(this);
        ipcTest.setText("测试独立运行进程 IPC");
        ipcTest.setOnClickListener(v -> testRuntimeProcess());
        page.addView(ipcTest);

        TextView note = new TextView(this);
        note.setText("当前版本提供 APK 信息管理和每实例私有目录；尚未实现第三方 APK 进程级虚拟运行。");
        note.setTextSize(13);
        note.setPadding(0, 12, 0, 16);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
    }

    private void testRuntimeProcess() {
        if (runtimeProcessClient != null) runtimeProcessClient.close();
        runtimeProcessClient = new RuntimeProcessClient(this);
        runtimeProcessClient.ping(new RuntimeProcessClient.Callback() {
            @Override public void onResult(String status, int pid, String processName) {
                runtimeProcessClient = null;
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("运行进程 IPC 测试")
                        .setMessage("状态：" + status
                                + "\nPID：" + pid
                                + "\n进程：" + processName
                                + "\n\n这是独立进程通信验证，不代表已运行导入 APK。")
                        .setPositiveButton("确定", null).show();
            }

            @Override public void onError(String message) {
                runtimeProcessClient = null;
                Toast.makeText(MainActivity.this, "IPC 测试失败：" + message,
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override protected void onDestroy() {
        if (runtimeProcessClient != null) {
            runtimeProcessClient.close();
            runtimeProcessClient = null;
        }
        super.onDestroy();
    }

    private void chooseApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        startActivityForResult(i, REQUEST_APK);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_APK || result != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            String id = UUID.randomUUID().toString();
            File apkDir = new File(getFilesDir(), "imported-apks");
            if (!apkDir.exists() && !apkDir.mkdirs()) throw new Exception("无法创建 APK 目录");
            File target = new File(apkDir, id + ".apk");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) throw new Exception("无法读取所选文件");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }

            PackageManager pm = getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(target.getAbsolutePath(),
                    PackageManager.GET_META_DATA);
            if (pi == null || pi.applicationInfo == null) {
                target.delete();
                throw new Exception("文件不是有效 APK，或无法解析");
            }
            pi.applicationInfo.sourceDir = target.getAbsolutePath();
            pi.applicationInfo.publicSourceDir = target.getAbsolutePath();
            String label = String.valueOf(pm.getApplicationLabel(pi.applicationInfo));
            String packageName = pi.packageName;
            String version = pi.versionName == null ? "未知" : pi.versionName;
            store.add(packageName, label, version, target.getAbsolutePath());
            refresh();
            Toast.makeText(this, "导入成功：" + label, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("导入失败")
                    .setMessage(e.getMessage() == null ? e.toString() : e.getMessage())
                    .setPositiveButton("确定", null).show();
        }
    }

    private void refresh() {
        list.removeAllViews();
        List<ProfileStore.AppRecord> apps = store.getAll();
        if (apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("尚未导入 APK");
            empty.setPadding(0, 24, 0, 24);
            list.addView(empty);
            return;
        }
        for (ProfileStore.AppRecord app : apps) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(18, 14, 18, 14);
            TextView info = new TextView(this);
            info.setText(app.label + "\n" + app.packageName + "\n版本：" + app.version
                    + "\n实例数：" + app.profiles.size());
            info.setTextSize(14);
            card.addView(info);

            LinearLayout actions = new LinearLayout(this);
            Button clone = new Button(this);
            clone.setText("新建实例");
            clone.setOnClickListener(v -> {
                store.createProfile(app.id);
                refresh();
                Toast.makeText(this, "已创建独立数据目录", Toast.LENGTH_SHORT).show();
            });
            actions.addView(clone);

            Button details = new Button(this);
            details.setText("实例详情");
            details.setOnClickListener(v -> showProfiles(app));
            actions.addView(details);

            Button remove = new Button(this);
            remove.setText("删除记录");
            remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setMessage("删除该 APK 导入记录及其实例目录？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, w) -> {
                        store.removeApp(app.id);
                        refresh();
                    }).show());
            actions.addView(remove);
            card.addView(actions);

            Button analyze = new Button(this);
            analyze.setText("分析 Application / 组件启动条件");
            analyze.setOnClickListener(v -> analyzeBootstrap(app));
            card.addView(analyze);

            list.addView(card);
            View divider = new View(this);
            divider.setBackgroundColor(0xFFDDDDDD);
            list.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        }
    }

    private void analyzeBootstrap(ProfileStore.AppRecord app) {
        try {
            ImportedApkDescriptor descriptor = ImportedApkDescriptorReader.read(
                    this, new File(app.apkPath));
            ApplicationBootstrapPlan plan = ApplicationBootstrapPlanner.analyze(descriptor);
            new AlertDialog.Builder(this)
                    .setTitle(app.label + " - Application 启动条件")
                    .setMessage(plan.toReport())
                    .setPositiveButton("关闭", null)
                    .show();
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("分析失败")
                    .setMessage(e.getMessage() == null ? e.toString() : e.getMessage())
                    .setPositiveButton("确定", null)
                    .show();
        }
    }

    private void showProfiles(ProfileStore.AppRecord app) {
        StringBuilder b = new StringBuilder();
        for (ProfileStore.Profile p : app.profiles) {
            b.append("实例：").append(p.id).append("\n目录：")
             .append(p.dataDir).append("\n\n");
        }
        if (b.length() == 0) b.append("尚未创建实例");
        new AlertDialog.Builder(this).setTitle(app.label + " - 实例")
                .setMessage(b.toString()).setPositiveButton("关闭", null).show();
    }
}
