package com.ssai.usbtool.virtual;

import android.content.Context;
import android.content.Intent;

import com.ssai.usbtool.ProxyActivity;

/**
 * Routes a selected virtual package/activity to USBTool's declared host proxy.
 *
 * The proxy is only a routing boundary. Android still instantiates ProxyActivity,
 * not the imported APK's Activity class. Real arbitrary-APK execution requires
 * framework-level component virtualization and is not implemented by this class.
 */
public final class VirtualLaunchRouter {
    public static final String EXTRA_PACKAGE_ID = "usbtool.virtual.PACKAGE_ID";
    public static final String EXTRA_PACKAGE_NAME = "usbtool.virtual.PACKAGE_NAME";
    public static final String EXTRA_ACTIVITY_NAME = "usbtool.virtual.ACTIVITY_NAME";
    public static final String EXTRA_PROFILE_ID = "usbtool.virtual.PROFILE_ID";
    public static final String EXTRA_TASK_ID = "usbtool.virtual.TASK_ID";

    private VirtualLaunchRouter() {}

    public static Intent createProxyIntent(Context context,
                                           String packageId,
                                           String packageName,
                                           String activityName) {
        return createProxyIntent(context, packageId, packageName, activityName,
                "default-profile", java.util.UUID.randomUUID().toString());
    }

    public static Intent createProxyIntent(Context context,
                                           String packageId,
                                           String packageName,
                                           String activityName,
                                           String profileId,
                                           String taskId) {
        Intent intent = new Intent(context, ProxyActivity.class);
        intent.putExtra(EXTRA_PACKAGE_ID, packageId);
        intent.putExtra(EXTRA_PACKAGE_NAME, packageName);
        intent.putExtra(EXTRA_ACTIVITY_NAME, activityName);
        intent.putExtra(EXTRA_PROFILE_ID, profileId);
        intent.putExtra(EXTRA_TASK_ID, taskId);
        return intent;
    }
}
