package com.ssai.usbtool.runtime.ipc;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * In-memory bookkeeping for logical runtime sessions in the :runtime process.
 *
 * A session here is only a record. It does not load APK code, instantiate an
 * imported Application/Activity, or create a separate Android UID/sandbox.
 */
public final class RuntimeSessionRegistry {
    private final Map<String, Session> sessions = new HashMap<>();

    public synchronized Session open(String profileId, String packageName) {
        require(profileId, "profileId");
        require(packageName, "packageName");
        Session session = new Session(UUID.randomUUID().toString(), profileId, packageName);
        sessions.put(session.id, session);
        return session;
    }

    public synchronized boolean close(String sessionId) {
        return sessionId != null && sessions.remove(sessionId) != null;
    }

    public synchronized int size() {
        return sessions.size();
    }

    public synchronized Session get(String sessionId) {
        return sessions.get(sessionId);
    }

    public synchronized Map<String, Session> snapshot() {
        return Collections.unmodifiableMap(new HashMap<>(sessions));
    }

    private static void require(String value, String name) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " 不能为空");
        }
    }

    public static final class Session {
        public final String id;
        public final String profileId;
        public final String packageName;
        public final long createdAtMillis;

        private Session(String id, String profileId, String packageName) {
            this.id = id;
            this.profileId = profileId;
            this.packageName = packageName;
            this.createdAtMillis = System.currentTimeMillis();
        }
    }
}
