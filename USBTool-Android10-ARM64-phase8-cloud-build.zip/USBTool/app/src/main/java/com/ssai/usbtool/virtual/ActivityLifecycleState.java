package com.ssai.usbtool.virtual;

/** Lifecycle states tracked by USBTool's host-side virtual task model. */
public enum ActivityLifecycleState {
    INITIALIZED, CREATED, STARTED, RESUMED, PAUSED, STOPPED, DESTROYED
}
