package com.ssai.usbtool.runtime.ipc;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import com.ssai.usbtool.runtime.ipc.RuntimeIpcProtocol;

/** One-shot UI-process client used to verify the private :runtime Binder endpoint. */
public final class RuntimeProcessClient {
    public interface Callback {
        void onResult(String status, int pid, String processName);
        void onError(String message);
    }

    private final Context appContext;
    private final Messenger clientMessenger;
    private Messenger remote;
    private ServiceConnection connection;
    private boolean bound;
    private Callback callback;

    public RuntimeProcessClient(Context context) {
        appContext = context.getApplicationContext();
        clientMessenger = new Messenger(new Handler(Looper.getMainLooper()) {
            @Override public void handleMessage(Message message) {
                if (message.what != RuntimeIpcProtocol.MSG_REPLY) return;
                Bundle data = message.getData();
                finish(data.getString(RuntimeIpcProtocol.KEY_STATUS),
                        data.getInt(RuntimeIpcProtocol.KEY_PID),
                        data.getString(RuntimeIpcProtocol.KEY_PROCESS_NAME),
                        data.getString(RuntimeIpcProtocol.KEY_ERROR));
            }
        });
    }

    public void ping(Callback callback) {
        if (this.callback != null) {
            throw new IllegalStateException("请求正在进行");
        }
        this.callback = callback;
        Intent intent = new Intent(appContext, RuntimeSessionService.class);
        connection = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName name, android.os.IBinder binder) {
                remote = new Messenger(binder);
                Message request = Message.obtain(null, RuntimeIpcProtocol.MSG_PING);
                request.replyTo = clientMessenger;
                try {
                    remote.send(request);
                } catch (RemoteException e) {
                    finish(null, -1, null, e.toString());
                }
            }

            @Override public void onServiceDisconnected(ComponentName name) {
                finish(null, -1, null, "运行进程连接断开");
            }
        };

        try {
            bound = appContext.bindService(intent, connection, Context.BIND_AUTO_CREATE);
            if (!bound) finish(null, -1, null, "无法绑定 :runtime 服务");
        } catch (SecurityException e) {
            finish(null, -1, null, e.toString());
        }
    }

    private void finish(String status, int pid, String processName, String error) {
        Callback target = callback;
        callback = null;
        close();
        if (target == null) return;
        if (error != null) target.onError(error);
        else target.onResult(status, pid, processName);
    }

    public void close() {
        if (bound && connection != null) {
            try { appContext.unbindService(connection); } catch (IllegalArgumentException ignored) { }
        }
        bound = false;
        connection = null;
        remote = null;
        callback = null;
    }
}
