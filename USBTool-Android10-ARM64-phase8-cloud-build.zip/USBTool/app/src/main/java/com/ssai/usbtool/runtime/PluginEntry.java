package com.ssai.usbtool.runtime;

import android.content.Context;
import android.view.View;

/**
 * Contract for a trusted USBTool demo plugin.
 *
 * This is NOT the Android Activity/Service component model. A plugin APK must
 * be built against this API and expose a public no-argument implementation.
 */
public interface PluginEntry {
    View createView(Context hostContext);
}
