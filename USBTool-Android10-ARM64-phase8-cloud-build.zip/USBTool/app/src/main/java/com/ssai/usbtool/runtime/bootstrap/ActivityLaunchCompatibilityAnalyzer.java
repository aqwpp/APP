package com.ssai.usbtool.runtime.bootstrap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Conservative analysis of manifest Activity task semantics. This is not a
 * launcher or a component dispatcher; it explains which Android task rules a
 * host ProxyActivity cannot faithfully impersonate.
 */
public final class ActivityLaunchCompatibilityAnalyzer {
    private ActivityLaunchCompatibilityAnalyzer() {}

    public static Analysis analyze(ImportedApkDescriptor apk) {
        ArrayList<String> blockers = new ArrayList<>();
        ArrayList<String> warnings = new ArrayList<>();
        if (apk == null) {
            blockers.add("APK 描述为空，无法分析 Activity 启动语义。");
            return new Analysis(blockers, warnings);
        }

        for (ImportedApkDescriptor.Component activity : apk.activities) {
            String name = activity.className == null ? "(unknown Activity)" : activity.className;
            if (!activity.enabled) {
                blockers.add(name + " 被 Manifest 禁用，不能作为正常启动目标。");
            }
            if (activity.activityLaunch == null) {
                warnings.add(name + " 缺少 ActivityInfo 启动属性快照；无法完整评估任务语义。");
                continue;
            }

            ImportedApkDescriptor.ActivityLaunchMetadata meta = activity.activityLaunch;
            String launchMode = value(meta.launchMode, "standard");
            if ("singleTask".equals(launchMode) || "singleInstance".equals(launchMode)
                    || "singleInstancePerTask".equals(launchMode)) {
                blockers.add(name + " 使用 " + launchMode + "；需要系统级任务栈复用/隔离语义，单一宿主 ProxyActivity 无法等价实现。");
            } else if ("singleTop".equals(launchMode)) {
                warnings.add(name + " 使用 singleTop；需要正确模拟 onNewIntent 与栈顶复用，当前代理尚未实现目标 Activity 回调。");
            } else if (!"standard".equals(launchMode)) {
                blockers.add(name + " 使用未知 launchMode=" + launchMode + "，不能安全推断启动行为。");
            }

            String documentMode = value(meta.documentLaunchMode, "none");
            if (!"none".equals(documentMode)) {
                blockers.add(name + " 使用 documentLaunchMode=" + documentMode + "；文档任务与 Recents 行为不能由当前代理准确重建。");
            }
            if (meta.taskAffinity != null && !meta.taskAffinity.isEmpty()
                    && !meta.taskAffinity.equals(apk.packageName)) {
                warnings.add(name + " 声明自定义 taskAffinity=" + meta.taskAffinity
                        + "；宿主任务归属与目标包任务归属不同。");
            }
            if (meta.targetActivity != null && !meta.targetActivity.isEmpty()) {
                warnings.add(name + " 是 Activity alias，目标组件为 " + meta.targetActivity
                        + "；alias 的名称、导出属性、主题和目标组件语义必须一起路由。");
            }
            if (meta.parentActivityName != null && !meta.parentActivityName.isEmpty()) {
                warnings.add(name + " 声明 parentActivityName=" + meta.parentActivityName
                        + "；当前代理尚未映射目标应用的 Up 导航栈。");
            }
            if (meta.permission != null && !meta.permission.isEmpty()) {
                blockers.add(name + " 受权限 " + meta.permission
                        + " 保护；USBTool 不能伪造目标 APK 的安装身份或权限主体。");
            }
            if (meta.noHistory || meta.finishOnTaskLaunch || meta.allowTaskReparenting
                    || meta.excludeFromRecents) {
                warnings.add(name + " 使用特殊任务标志（noHistory/finishOnTaskLaunch/allowTaskReparenting/excludeFromRecents 中至少一项）；需要单独实现并验证任务行为。");
            }
            if (meta.directBootAware) {
                warnings.add(name + " 标记 directBootAware；当前逻辑实例目录不是 Android 设备保护存储/凭据保护存储模型。");
            }
            if (meta.themeResourceId != 0) {
                warnings.add(name + " 指定了目标 APK 主题资源；当前 ProxyActivity 使用宿主主题，尚未解析并应用目标主题。");
            }
            if (meta.configChanges != 0 || meta.screenOrientation != -1) {
                warnings.add(name + " 声明 configChanges/screenOrientation；宿主代理的配置变化与目标 Activity 回调尚未映射。");
            }
        }
        return new Analysis(blockers, warnings);
    }

    private static String value(String s, String fallback) {
        return s == null || s.isEmpty() ? fallback : s;
    }

    public static final class Analysis {
        public final List<String> blockers;
        public final List<String> warnings;
        private Analysis(List<String> blockers, List<String> warnings) {
            this.blockers = Collections.unmodifiableList(new ArrayList<>(blockers));
            this.warnings = Collections.unmodifiableList(new ArrayList<>(warnings));
        }
    }
}
