package com.ssai.usbtool.runtime.ipc;

import org.junit.Test;
import static org.junit.Assert.*;

public class RuntimeSessionRegistryTest {
    @Test public void openAndCloseSessionRecord() {
        RuntimeSessionRegistry registry = new RuntimeSessionRegistry();
        RuntimeSessionRegistry.Session session = registry.open("profile-1", "sample.app");
        assertNotNull(session.id);
        assertEquals(1, registry.size());
        assertEquals("profile-1", registry.get(session.id).profileId);
        assertTrue(registry.close(session.id));
        assertEquals(0, registry.size());
        assertFalse(registry.close(session.id));
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsEmptyProfileId() {
        new RuntimeSessionRegistry().open(" ", "sample.app");
    }
}
