package com.ssai.usbtool.runtime.bootstrap;

import org.junit.Test;
import static org.junit.Assert.*;

public class ActivityLaunchCompatibilityAnalyzerTest {
    private ImportedApkDescriptor apk() {
        ImportedApkDescriptor apk = new ImportedApkDescriptor();
        apk.packageName = "sample.app";
        apk.apkPath = "/tmp/sample.apk";
        apk.hasCode = true;
        apk.defaultProcessName = "sample.app";
        return apk;
    }

    private ImportedApkDescriptor.Component activity(String name, boolean enabled,
            ImportedApkDescriptor.ActivityLaunchMetadata metadata) {
        return new ImportedApkDescriptor.Component(name, "sample.app", enabled, true,
                false, null, metadata);
    }

    private ImportedApkDescriptor.ActivityLaunchMetadata meta(String launch, String document,
            String affinity, String permission, boolean noHistory) {
        return new ImportedApkDescriptor.ActivityLaunchMetadata(launch, document, affinity,
                permission, null, null, 0, 0, -1, false, noHistory, false, false, false);
    }

    @Test public void standardActivityHasNoActivitySpecificBlocker() {
        ImportedApkDescriptor apk = apk();
        apk.activities.add(activity("sample.app.Main", true,
                meta("standard", "none", "sample.app", null, false)));
        ActivityLaunchCompatibilityAnalyzer.Analysis a =
                ActivityLaunchCompatibilityAnalyzer.analyze(apk);
        assertTrue(a.blockers.isEmpty());
        assertTrue(a.warnings.isEmpty());
    }

    @Test public void singleTaskAndDocumentModeAreBlockers() {
        ImportedApkDescriptor apk = apk();
        apk.activities.add(activity("sample.app.Main", true,
                meta("singleTask", "always", "sample.app", null, false)));
        ActivityLaunchCompatibilityAnalyzer.Analysis a =
                ActivityLaunchCompatibilityAnalyzer.analyze(apk);
        assertTrue(a.blockers.toString().contains("singleTask"));
        assertTrue(a.blockers.toString().contains("documentLaunchMode=always"));
    }

    @Test public void singleTopAndSpecialFlagsAreWarnings() {
        ImportedApkDescriptor apk = apk();
        apk.activities.add(activity("sample.app.Main", true,
                meta("singleTop", "none", "sample.app.alt", null, true)));
        ActivityLaunchCompatibilityAnalyzer.Analysis a =
                ActivityLaunchCompatibilityAnalyzer.analyze(apk);
        assertTrue(a.blockers.isEmpty());
        assertTrue(a.warnings.toString().contains("singleTop"));
        assertTrue(a.warnings.toString().contains("自定义 taskAffinity"));
        assertTrue(a.warnings.toString().contains("特殊任务标志"));
    }

    @Test public void disabledAndPermissionProtectedActivitiesAreBlocked() {
        ImportedApkDescriptor apk = apk();
        apk.activities.add(activity("sample.app.Secret", false,
                meta("standard", "none", "sample.app", "sample.app.permission.OPEN", false)));
        ActivityLaunchCompatibilityAnalyzer.Analysis a =
                ActivityLaunchCompatibilityAnalyzer.analyze(apk);
        assertTrue(a.blockers.toString().contains("被 Manifest 禁用"));
        assertTrue(a.blockers.toString().contains("sample.app.permission.OPEN"));
    }
}
