package com.ssai.usbtool.virtual;

import org.junit.Test;
import static org.junit.Assert.*;

public class VirtualTaskStackTest {
    @Test public void pushPeekPopMaintainsTaskOrder() {
        VirtualTaskStack stack = new VirtualTaskStack();
        VirtualActivityRecord first = new VirtualActivityRecord(
                "task-a", "profile-a", "pkg-id", "sample.app", "sample.app.Main");
        VirtualActivityRecord second = new VirtualActivityRecord(
                "task-a", "profile-a", "pkg-id", "sample.app", "sample.app.Detail");

        stack.push(first);
        stack.push(second);
        assertEquals(second, stack.peek("task-a"));
        assertEquals(2, stack.snapshot("task-a").size());
        assertEquals(second, stack.pop("task-a"));
        assertEquals(first, stack.peek("task-a"));
        assertEquals(ActivityLifecycleState.DESTROYED, second.getState());
    }

    @Test public void lifecycleRejectsInvalidTransition() {
        VirtualActivityRecord record = new VirtualActivityRecord(
                "task-b", "profile-b", "pkg-id", "sample.app", "sample.app.Main");
        VirtualActivityLifecycle.moveTo(record, ActivityLifecycleState.CREATED);
        VirtualActivityLifecycle.moveTo(record, ActivityLifecycleState.STARTED);
        VirtualActivityLifecycle.moveTo(record, ActivityLifecycleState.RESUMED);
        try {
            VirtualActivityLifecycle.moveTo(record, ActivityLifecycleState.STOPPED);
            fail("RESUMED -> STOPPED should be rejected; PAUSED must come first");
        } catch (IllegalStateException expected) {
            assertEquals(ActivityLifecycleState.RESUMED, record.getState());
        }
    }

    @Test public void clearProfileRemovesOnlyMatchingRecords() {
        VirtualTaskStack stack = new VirtualTaskStack();
        VirtualActivityRecord a = new VirtualActivityRecord(
                "task-a", "profile-a", "pkg-id", "sample.app", "sample.app.Main");
        VirtualActivityRecord b = new VirtualActivityRecord(
                "task-b", "profile-b", "pkg-id", "sample.app", "sample.app.Main");
        stack.push(a);
        stack.push(b);
        stack.clearProfile("profile-a");
        assertNull(stack.peek("task-a"));
        assertEquals(b, stack.peek("task-b"));
    }
}
