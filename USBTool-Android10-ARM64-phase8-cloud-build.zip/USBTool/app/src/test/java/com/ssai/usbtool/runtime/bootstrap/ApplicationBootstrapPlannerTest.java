package com.ssai.usbtool.runtime.bootstrap;

import org.junit.Test;
import static org.junit.Assert.*;

public class ApplicationBootstrapPlannerTest {
    @Test public void ordinaryActivityApkIsMetadataOnlyAndNeedsFrameworkRuntime() {
        ImportedApkDescriptor apk = new ImportedApkDescriptor();
        apk.packageName = "test.app";
        apk.apkPath = "/tmp/test.apk";
        apk.hasCode = true;
        apk.applicationClass = "android.app.Application";
        apk.defaultProcessName = "test.app";
        apk.targetSdkVersion = 29;
        apk.activities.add(new ImportedApkDescriptor.Component(
                "test.app.MainActivity", "test.app", true, true, false, null));

        ApplicationBootstrapPlan plan = ApplicationBootstrapPlanner.analyze(apk);
        assertEquals(ApplicationBootstrapPlan.Status.METADATA_ANALYSIS_COMPLETE, plan.status);
        assertTrue(plan.requiresAndroidFrameworkPackageRuntime);
        assertFalse(plan.blockers.isEmpty());
        assertTrue(plan.toReport().contains("没有实例化 Application"));
    }

    @Test public void detectsMissingArm64NativeAbi() {
        ImportedApkDescriptor apk = new ImportedApkDescriptor();
        apk.packageName = "native.app";
        apk.apkPath = "/tmp/native.apk";
        apk.hasCode = true;
        apk.defaultProcessName = "native.app";
        apk.nativeAbis.add("armeabi-v7a");
        ApplicationBootstrapPlan plan = ApplicationBootstrapPlanner.analyze(apk);
        assertTrue(plan.blockers.toString().contains("arm64-v8a"));
    }

    @Test public void detectsMultipleProcessesAndIsolatedService() {
        ImportedApkDescriptor apk = new ImportedApkDescriptor();
        apk.packageName = "multi.app";
        apk.apkPath = "/tmp/multi.apk";
        apk.hasCode = true;
        apk.defaultProcessName = "multi.app";
        apk.services.add(new ImportedApkDescriptor.Component(
                "multi.app.RemoteService", "multi.app:remote", true, false, true, null));
        ApplicationBootstrapPlan plan = ApplicationBootstrapPlanner.analyze(apk);
        assertTrue(plan.blockers.toString().contains("多个进程"));
        assertTrue(plan.blockers.toString().contains("isolatedProcess"));
    }

    @Test public void invalidDescriptorIsRejected() {
        ApplicationBootstrapPlan plan = ApplicationBootstrapPlanner.analyze(null);
        assertEquals(ApplicationBootstrapPlan.Status.INVALID_APK_METADATA, plan.status);
    }
}
