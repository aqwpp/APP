#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
gradle --no-daemon clean :app:assembleDebug :fixture:assembleDebug
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/USBTool-debug.apk
cp fixture/build/outputs/apk/debug/fixture-debug.apk dist/USBTool-fixture-debug.apk
echo "USBTool APK: $(pwd)/dist/USBTool-debug.apk"
echo "Fixture APK: $(pwd)/dist/USBTool-fixture-debug.apk"
