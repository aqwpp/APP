# USBTool (Phase 1)

Package: `com.ssai.usbtool`  
Device target: Android 10 (API 29), arm64-v8a  
Signing: V1 JAR signing enabled. V2 disabled in the sample release config.

## What this project implements
- APK picker using Storage Access Framework (no broad storage permission)
- APK package name / label / version metadata parsing
- Import APK into app-private storage
- Create multiple logical profiles for an imported package
- Per-profile private data directories under `files/virtual-users/<profile-id>/`
- Profile list and delete operation

## Important limitation
This is a management/import/storage-isolation foundation, **not yet a complete VirtualApp-compatible runtime**. An ordinary Android app cannot launch arbitrary imported APKs as independent installed apps merely by copying their files. A real runtime needs compatible component/process scheduling, package/resource/permission virtualization and extensive Android 10 framework integration. Do not treat the profile records as process-level isolation.

The project does not copy VirtualApp source. Review the upstream repository's current licensing/IP notice before using any of its code.

## Build
1. Open this folder in Android Studio (AGP 8.6.1; JDK 17).
2. Let Gradle sync and install Android SDK Platform 35.
3. Create a signing keystore, for example:
   `keytool -genkeypair -v -keystore usbtool-release.jks -alias usbtool -keyalg RSA -keysize 2048 -validity 10000`
4. Set environment variables `USBTOOL_STORE_FILE`, `USBTOOL_STORE_PASSWORD`, `USBTOOL_KEY_ALIAS`, `USBTOOL_KEY_PASSWORD`, or edit `app/build.gradle`.
5. Build `:app:assembleRelease`.

The release signing config enables V1 and disables V2 to produce a V1-signed APK. For Play distribution or modern deployment, consider enabling V2 as well; Android 10 supports both.

## Next engineering milestones
1. Add a dedicated runtime process and a documented plugin contract.
2. Implement supported component proxying and lifecycle routing for a deliberately limited test app.
3. Add package/resource resolution and permission mediation.
4. Add robust per-profile data routing and IPC.
5. Test against Android 10 arm64 devices and a controlled test APK.

No root access, stealth, signature bypass, anti-detection, or security-control evasion is implemented.

## Phase 2: trusted plugin DEX prototype

Added `runtime/PluginEntry.java` and `runtime/PluginRuntime.java`. This is a
narrow proof-of-concept for loading a trusted APK that was specifically built
to implement the shared `PluginEntry` interface and return a host `View`.
It is not a general Android APK virtual machine and does not isolate plugin
permissions or UID. Loaded code runs with the host app's privileges.

Do not use this loader with arbitrary or untrusted APKs. The next test should
be a purpose-built sample plugin compiled against the same interface contract.

## Phase 3: virtual package registry and launch routing

Added:
- `virtual/VirtualPackageManager.java`: parses APK metadata using public
  PackageManager archive APIs and stores package/activity metadata in a
  private registry.
- `virtual/VirtualLaunchRouter.java`: builds an explicit intent to a host-side
  proxy Activity.
- `ProxyActivity.java`: a declared host proxy screen showing the selected
  target component and the current runtime limitation.

Important: this is a package registry and routing scaffold, not a functioning
arbitrary-APK runtime. The Android framework will instantiate the host
ProxyActivity only. It will not instantiate an Activity class from an APK that
is not installed. A complete VirtualApp-style runtime requires substantial
Android 10 framework integration, component dispatch, resource resolution,
process lifecycle and permission handling. The project does not bypass Android
signature checks or install third-party packages silently.

## Phase 4: host-side Activity scheduling model

Added:
- `virtual/ActivityLifecycleState.java`
- `virtual/VirtualActivityRecord.java`
- `virtual/VirtualTaskStack.java`
- `virtual/VirtualActivityLifecycle.java`
- Extended `VirtualLaunchRouter` with profile/task identifiers
- Updated `ProxyActivity` to track the host proxy lifecycle
- `app/src/test/.../VirtualTaskStackTest.java` unit tests

Scope and limitations:
- The task stack is in-memory only and is not Android's ActivityTaskManager.
- Lifecycle callbacks belong to the host `ProxyActivity`; they are not delivered
  to the imported APK's Activity implementation.
- This stage does not execute arbitrary imported APK Activities, Services,
  Providers, or Receivers and does not provide process-level data isolation.

## Phase 5: imported APK DEX/resource diagnostics

Added:
- `runtime/ImportedApkRuntimeProbe.java`

The probe reports:
1. Whether PackageManager can parse the imported APK archive metadata.
2. Whether DexClassLoader can resolve the declared Application class with
   initialization disabled (`Class.forName(..., false, loader)`).
3. Whether archive resources can be opened through reflective
   `AssetManager.addAssetPath`, and whether `string/app_name` is readable.

Important Android 10 limitation:
- `AssetManager.addAssetPath` is a hidden/non-SDK API. Reflection can be
  restricted by Android non-SDK interface policy and OEM builds. This is an
  experiment/diagnostic, not a production compatibility guarantee.
- Resolving a class does not instantiate the app's Application, Activity,
  Services, Providers, or Receivers.
- DexClassLoader code runs under USBTool's UID and permission set. It is not a
  security sandbox and must only be used with trusted test APKs.
- The probe intentionally avoids initializing or invoking imported classes.

Suggested controlled test:
1. Build a tiny test APK with a custom `Application`, one Activity and a
   `string/app_name` resource.
2. Import it using USBTool's existing APK import flow.
3. Call `ImportedApkRuntimeProbe.inspect(context, apkFile)` from a debug-only
   action and inspect `ProbeResult.toReport()`.
4. Record the exact Android 10 device build and whether `RESOURCE_ARCHIVE_OPENED`
   or `RESOURCE_ACCESS_BLOCKED_OR_FAILED` is returned.

This phase does not claim arbitrary APK execution or per-profile process/data
isolation.

## Phase 6: private runtime process and Binder IPC skeleton

Added:
- `runtime/ipc/RuntimeIpcProtocol.java`: Messenger message contract
- `runtime/ipc/RuntimeSessionRegistry.java`: process-local logical session records
- `runtime/ipc/RuntimeSessionService.java`: private Service declared in `:runtime`
- `runtime/ipc/RuntimeProcessClient.java`: one-shot UI-process Messenger client
- Main screen button: `测试独立运行进程 IPC`
- `RuntimeSessionRegistryTest.java`: registry unit tests

Manifest:
- `RuntimeSessionService` is `android:exported="false"` and runs in
  `android:process=":runtime"`.

What this proves when installed and tested:
- Android can start USBTool's secondary process.
- The UI process can bind to the private Service over Binder/Messenger.
- The service reports its PID and process name.
- The protocol has logical open/close session-record messages.

Important security and runtime boundaries:
- Android processes declared by one APK share that APK's Linux UID and app
  permissions. `:runtime` is process separation, not a security sandbox.
- The session registry is memory-only and is reset when that process dies.
- No imported DEX is loaded or invoked by the service.
- No foreign Application/Activity is instantiated. A real arbitrary-APK
  runtime still needs a compatible component dispatch layer and, for robust
  isolation, a platform-supported separate UID/package installation or an
  authorized OS/framework integration. A normal app cannot grant itself that.
- Do not send untrusted APK paths to this service and do not treat this IPC
  channel as a trust boundary.

Manual Android 10 test:
1. Build/install the debug APK on an API 29 ARM64 device.
2. Launch USBTool and tap `测试独立运行进程 IPC`.
3. Confirm status `RUNTIME_PROCESS_READY`, process name ending in `:runtime`,
   and a PID different from the UI process PID (the latter can be checked with
   `adb shell ps -A | grep com.ssai.usbtool`).
4. Repeat after force-stop; the process should be recreated on demand.
5. Test app import separately; IPC success does not imply APK execution.

## Debug APK build helper

The Debug variant is configured for the Android Gradle Plugin's generated
debug keystore (no user JKS required), with V1 signing enabled and V2 signing
disabled for the requested Android 10 test target.

Build host requirements:
- JDK 17
- Gradle 8.7
- Android SDK Platform 35 and Build Tools 35.0.0
- `ANDROID_HOME` or `ANDROID_SDK_ROOT` configured

Run `./build-debug.sh` on Linux/macOS or `BUILD-DEBUG-WINDOWS.bat` on Windows.
The resulting file is copied to `dist/USBTool-debug.apk`.

This environment does not currently have Gradle or Android SDK installed, so
the APK itself has not been built here. The generated debug key is a test key,
not a stable release-signing identity.

## Phase 7: Application bootstrap feasibility analysis

Added under `app/src/main/java/com/ssai/usbtool/runtime/bootstrap/`:
- `ImportedApkDescriptor.java`: manifest-derived summary model.
- `ImportedApkDescriptorReader.java`: reads PackageManager archive metadata,
  declared components/permissions, and native ABI names from the APK ZIP. It
  does not load DEX classes or invoke APK code.
- `ApplicationBootstrapPlanner.java`: pure-Java conservative compatibility
  analysis.
- `ApplicationBootstrapPlan.java`: human-readable report.

The imported-app card now has a `启动条件分析` action. It reports custom
Application declarations, Activity/Service/Receiver/Provider counts, process
model, sharedUserId, requested permissions, native ABIs and SDK constraints.

Important boundary:
- This is a metadata-only planner, not a virtual Application implementation.
- Android creates a normal app's Application through internal
  ActivityThread/LoadedApk package-loading machinery and installs providers and
  components as part of framework-managed startup. The public SDK does not
  expose a supported API for a third-party host to recreate that full package
  runtime for an uninstalled APK.
- Constructing an Application object manually or calling hidden attach methods
  is not equivalent to a real app process and is intentionally not attempted.
- The `:runtime` process still shares USBTool's UID. It is not a permission or
  data-isolation boundary. Never load untrusted APK code there.

Validation on this development host:
- Pure-Java planner/model compilation and smoke tests are run independently.
- Android-specific PackageManager reader and UI wiring require Android Gradle
  compilation and API 29 device validation; those are not claimed as passed
  unless a built APK and device test are available.

Next engineering gate:
1. Build a small self-authored API 29 test APK with a custom Application,
   one Activity, one Service, one Receiver and one Provider.
2. Import it and compare the planner output with its source Manifest.
3. Only after metadata correctness is confirmed, evaluate whether the product
   should target an authorized OS-level package runtime or switch to a
   supported plugin model. A regular app cannot safely provide arbitrary APK
   UID/package identity virtualization on stock Android 10.

### Controlled test APK fixture

A separate `:fixture` application module is included for repeatable manifest
analysis. Build it with:

`gradle :fixture:assembleDebug`

Expected artifact:
`fixture/build/outputs/apk/debug/fixture-debug.apk`

The fixture is self-authored and contains a custom `Application`, launcher
Activity, isolated-process Service, non-exported Receiver, non-exported
Provider, one requested normal permission, and an `app_name` resource. Build
and install it normally if desired, then import its APK into USBTool and tap
`分析 Application / 组件启动条件`. The report should identify all declared
component families, the custom Application, the isolated/multiple process
model and requested permission. This fixture is for metadata and lifecycle
experiments only; it is not a plugin and is not intended to be run inside
USBTool.

The updated build helpers now build both `:app` and `:fixture` and copy both
Debug APKs into `dist/`:
- `dist/USBTool-debug.apk` (V1-only debug signing configured in the USBTool app)
- `dist/USBTool-fixture-debug.apk` (self-authored metadata test fixture)


## Phase 8: Activity task/launch compatibility analysis

Added: `runtime/bootstrap/ActivityLaunchCompatibilityAnalyzer.java`. The
archive reader now snapshots public `ActivityInfo` fields for each Activity:
launchMode, documentLaunchMode, taskAffinity, permission, theme resource ID,
configuration-change mask, screen orientation, directBootAware and selected
task flags. The existing Application bootstrap report now includes a separate
set of Activity-specific blockers/warnings.

The analyzer is intentionally conservative:
- `singleTask`, `singleInstance`, non-default document launch modes and
  permission-protected Activities are reported as blockers.
- `singleTop`, custom task affinity, direct-boot behavior, target theme and
  configuration callbacks are reported as warnings requiring explicit support.
- It does not discover or execute launcher intent filters, does not start an
  imported Activity, and does not make ProxyActivity equivalent to ActivityThread.

The fixture now includes `FixtureSingleTaskActivity` with `singleTask`, a
custom task affinity and portrait orientation so the analyzer has a concrete
manifest case to inspect.

Manual validation on Android 10: import the built fixture APK in USBTool, tap
“分析 Application / 组件启动条件”, and verify that the report identifies
`FixtureSingleTaskActivity`, `singleTask`, custom task affinity and orientation.
Also verify the existing isolated service/provider/receiver findings. This
validates metadata inspection only, not execution of the fixture components.

The Activity snapshot also records `targetActivity` and `parentActivityName`
to detect Activity aliases and parent/Up navigation declarations.


## 手机云端构建

请按 `MOBILE-CLOUD-BUILD.md` 将源码提交到 GitHub，然后在 Actions 页面手动运行 `USBTool Android Debug APK`。该工作流会构建并检查主程序和 fixture 的 Debug APK（V1 签名、V2 关闭），并上传 30 天可下载的构建产物。
